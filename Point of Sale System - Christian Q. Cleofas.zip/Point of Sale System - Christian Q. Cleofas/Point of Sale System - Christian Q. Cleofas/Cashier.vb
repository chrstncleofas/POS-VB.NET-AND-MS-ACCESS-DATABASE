﻿Imports System.Drawing.Printing
Public Class Cashier
    Dim WithEvents PD As New PrintDocument
    Dim PPD As New PrintPreviewDialog
    Dim longpaper As Integer
    Sub changelongpaper()
        Dim rowcount As Integer
        longpaper = 0
        rowcount = dgtemp.Rows.Count
        longpaper = rowcount * 15
        longpaper = longpaper + 300
    End Sub
    Dim xUP As Double
    Dim xDesc As String
    Dim xtempq As String
    Dim xGTotal As Double
    Dim crit As Integer
    Dim xqty As Integer
    Dim xsn As String
    Dim xtotal As Integer
    Dim xtime As String
    Dim stocksqty As Integer
    Public XName As String
    Dim crits As Integer
    Sub lock()
        txtQ.Enabled = False
        txtamt.Enabled = False
    End Sub
    Sub unlock()
        txtQ.Enabled = True
        txtamt.Enabled = True
    End Sub
    Sub clearing()
        txtSN.Text = ""
        txtDesc.Text = ""
        txtQ.Text = ""
        lblchange.Text = "0.00"
        txtamt.Text = "0.00"
        lblTotal.Text = "0.00"
        lblDisplay.Text = "0.00"
        lblVAT.Text = "0.00"
    End Sub
    Sub subcritical()
        'Critical Item
        crits = dbds.Tables("tblstock").Rows(0).Item("Product Quantity")
        If crits <= 5 And crits >= 1 Then
            MsgBox("This item is in only " & crits, vbCritical, "WARNING.!!!!")
        ElseIf crits = 0 Then
            MsgBox("This item has been out of stock", vbCritical, "WARNING!!!!!")
            clearing()
        End If
        'End of Critical Codes
    End Sub
    Private Sub Timer1_Tick(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Timer1.Tick
        'lblDate.Text = Format(Now, "dd MMMM, yyyy - hh:mm:ss tt")
    End Sub
    Private Sub Cashier_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        changelongpaper()
        Call CenterToScreen()
        Me.FormBorderStyle = Windows.Forms.FormBorderStyle.None
        Me.WindowState = FormWindowState.Maximized
        opendb3()
        sqlquery3()
        dgtemp.DataSource = dbds.Tables("tbltemp")
        lock()
        txtSN.Focus()
        d1.Format = DateTimePickerFormat.Custom
        d1.CustomFormat = "MMMM dd, yyyy"
        t1.Format = DateTimePickerFormat.Time
        t1.CustomFormat = "HH:mm:ss tt"
        'Timer1.Enabled = True
        xGTotal = 0
    End Sub
    Private Sub txtSN_KeyDown(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyEventArgs) Handles txtSN.KeyDown
        If e.KeyCode = Keys.Enter Then
            Try
                tblstock = New OleDb.OleDbDataAdapter("SELECT * FROM tblstock WHERE [Product ID] like '" & txtSN.Text.Trim & "' ", db)
                dbds = New DataSet()
                tblstock.Fill(dbds, "tblstock")
                txtQ.Enabled = True
                If dbds.Tables("tblstock").Rows.Count > 0 Then
                    xUP = dbds.Tables("tblstock").Rows(0).Item("Selling Price")
                    xUP = FormatCurrency(xUP)
                    'Critical Function
                    subcritical()
                    'End of Function
                    txtDesc.Text = dbds.Tables("tblstock").Rows(0).Item("Product Description")
                    tbltemp = New OleDb.OleDbDataAdapter("SELECT * FROM tbltemp WHERE [Stock No] like '" & txtSN.Text.Trim & "'", db)
                    dbds = New DataSet()
                    tbltemp.Fill(dbds, "tbltemp")
                    If dbds.Tables("tbltemp").Rows.Count > 0 Then
                        If MsgBox("This item is already on your list, Would you like to add this one?", vbQuestion + vbYesNo, "Cashier Form") = vbYes Then
                            xtempq = dbds.Tables("tbltemp").Rows(0).Item("Quantity")
                            xGTotal = dbds.Tables("tbltemp").Rows(0).Item("Total")
                            txtQ.Focus()
                            sw = False
                        Else
                            txtSN.Clear()
                            lblDisplay.Text = "0.00"
                            txtDesc.Text = ""
                            Exit Sub
                        End If
                        Exit Sub
                    Else
                        sw = True
                        txtQ.Focus()
                    End If
                Else
                    MsgBox("Please enter a valid a Stock No., Thank you!", vbCritical, "Undefined Stock No.")
                    txtSN.Clear()
                    txtSN.Focus()
                End If
            Catch err As Exception
                MsgBox(err.ToString, vbCritical, "Error")
            Finally
                db.Close()
            End Try
        End If
    End Sub
    Private Sub txtQ_KeyDown(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyEventArgs) Handles txtQ.KeyDown
        If e.KeyCode = Keys.Enter Then
            txtamt.Enabled = True
            dgtemp.DataSource = dbds.Tables("tbltemp")
            If txtQ.Text = "" Then
                MsgBox("Kindly enter the no. of quantity for this Item(s)!, Thank you...", vbCritical, "oops")
                txtQ.Focus()
                Exit Sub
            End If
            If e.KeyCode = Keys.Enter Then
                xGTotal = CInt(xGTotal) + CDbl(lblTotal.Text)
                lblDisplay.Text = Format(xGTotal, "Standard")
                db.Open()
                If sw = True Then
                    dbcmd = New OleDb.OleDbCommand("INSERT INTO tbltemp([Stock No],[Description],[Quantity],[Unit Price],[Total],[VAT]) VALUES ('" & txtSN.Text.Trim & "','" & txtDesc.Text.Trim & "','" & txtQ.Text.Trim & "','" & xUP & "','" & lblTotal.Text.Trim & "', '" & lblVAT.Text.Trim & "')", db)
                    dbcmd.ExecuteNonQuery()
                Else
                    xtempq = xtempq + CInt(txtQ.Text)
                    xGTotal = CSng(xGTotal) + CSng(lblTotal.Text)
                    lblDisplay.Text = FormatCurrency(lblDisplay.Text)
                    dbcmd = New OleDb.OleDbCommand("UPDATE tbltemp set [Quantity]='" & xtempq & "',[Total]='" & lblDisplay.Text & "' WHERE [Stock No] like '" & txtSN.Text & "'", db)
                    dbcmd.ExecuteNonQuery()
                End If
                sqlquery3()
                dgtemp.DataSource = dbds.Tables("tbltemp")
                txtQ.Clear()
                txtSN.Clear()

                'Total funtion by Quantity
                tbltemp = New OleDb.OleDbDataAdapter("SELECT sum([Total]) + sum([VAT]) as xt FROM tbltemp", db)
                dbds = New DataSet()
                tbltemp.Fill(dbds, "tbltemp")
                If dbds.Tables("tbltemp").Rows.Count > 0 Then
                    recpointer = 0
                    trec = CInt(dbds.Tables("tbltemp").Rows.Count) - 1
                End If
                lblDisplay.Text = dbds.Tables("tbltemp").Rows(0).Item("xt")
                lblDisplay.Text = FormatCurrency(lblDisplay.Text)
                'txtamt.Focus()
                'txtamt.SelectAll()
                txtSN.Focus()
            End If
        End If
    End Sub
    Private Sub txtQ_TextChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles txtQ.TextChanged
        Try
            lblTotal.Text = CInt(txtQ.Text) * CInt(xUP)
            lblVAT.Text = CInt(txtQ.Text) * 0.3
            lblTotal.Text = FormatCurrency(lblTotal.Text)
        Catch err As Exception
            'MsgBox(err.ToString)
        End Try
    End Sub
    Private Sub txtamt_KeyDown(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyEventArgs) Handles txtamt.KeyDown
        xDesc = txtDesc.Text
        xsn = txtSN.Text
        xtotal = lblDisplay.Text
        If e.KeyCode = Keys.Enter Then
            txtDesc.Text = ""
            lblTotal.Text = "0.00"
            If CSng(txtamt.Text) < CSng(lblDisplay.Text) Then
                MsgBox("Oops, but you have an insufficiecnt money to make this transaction!", vbInformation, "wait a minute..")
                txtamt.Text = ""
                Exit Sub
            End If
            lblchange.Text = CSng(txtamt.Text) - CSng(lblDisplay.Text)
            txtamt.Text = FormatCurrency(txtamt.Text)
            lblchange.Text = FormatCurrency(lblchange.Text)
            tbltemp = New OleDb.OleDbDataAdapter("SELECT * FROM tbltemp", db)
            dbds = New DataSet()
            tbltemp.Fill(dbds, "tbltemp")
            trec = dbds.Tables("tbltemp").Rows.Count - 1
            recpointer = 0
            For recpointer As Integer = 0 To trec
                db.Open()
                xDesc = dbds.Tables("tbltemp").Rows(recpointer).Item("Description")
                xUP = dbds.Tables("tbltemp").Rows(recpointer).Item("Unit Price")
                xqty = dbds.Tables("tbltemp").Rows(recpointer).Item("Quantity")
                xsn = dbds.Tables("tbltemp").Rows(recpointer).Item("Stock No")
                xtotal = dbds.Tables("tbltemp").Rows(recpointer).Item("Total")
                dbcmd = New OleDb.OleDbCommand("INSERT INTO tbltran([Stock No],[Description],[Quantity],[Unit Price],[Total], [Date Time], [Cashier Name]) VALUES ('" & xsn & "','" & xDesc & "','" & xqty & "','" & FormatCurrency(xUP) & "','" & FormatCurrency(xtotal) & "','" & d1.Value & "','" & txtCashier.Text & "')", db)
                dbcmd.ExecuteNonQuery()
                db.Close()
                db.Open()
                tblstock = New OleDb.OleDbDataAdapter("SELECT * FROM tblstock WHERE [Product ID] like '" & xsn & "' ", db)
                dbds = New DataSet()
                tblstock.Fill(dbds, "tblstock")
                stocksqty = dbds.Tables("tblstock").Rows(0).Item("Product Quantity")
                stocksqty = stocksqty - xqty
                dbcmd = New OleDb.OleDbCommand("UPDATE tblstock set [Product Quantity] = '" & stocksqty & "' WHERE [Product ID] like '" & xsn & "'", db)
                dbcmd.ExecuteNonQuery()
                sqlquery3()
                db.Close()
            Next
        End If
    End Sub
    Private Sub MainToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MainToolStripMenuItem.Click
        If MsgBox("This action will close the the transaction window, the next user will be ask to log - in! Do you wish to continue?", vbQuestion + vbYesNo, "logging - off") = vbYes Then
            Dim counter As Integer
            For counter = 90 To 10 Step -20
                Me.Opacity = counter / 100
                Me.Refresh()
                Threading.Thread.Sleep(5)
            Next counter
            If LoginForm.xpriv = "Admin" Then
                MainForm.Show()
                Me.Close()
            Else
                LoginForm.Show()
                Me.Close()
            End If
        End If
    End Sub
    Private Sub InventoryToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ClearToolStripMenuItem.Click
        opendb3()
        sqlquery3()
        lock()
        db.Open()
        dbcmd = New OleDb.OleDbCommand("delete * from tbltemp", db)
        dbcmd.ExecuteNonQuery()
        dgtemp.DataSource = dbds.Tables("tbltemp")
        txtSN.Focus()
        clearing()
    End Sub
    Private Sub PrintDocument1_BeginPrint(ByVal sender As Object, ByVal e As System.Drawing.Printing.PrintEventArgs) Handles PrintDocument1.BeginPrint
        Dim pagesetup As New PageSettings
        'pagesetup.PaperSize = New PaperSize("Custom", 250, 500) 'fixed size
        pagesetup.PaperSize = New PaperSize("Custom", 250, longpaper)
        PrintDocument1.DefaultPageSettings = pagesetup
    End Sub
    Private Sub PrintDocument1_PrintPage(ByVal sender As System.Object, ByVal e As System.Drawing.Printing.PrintPageEventArgs) Handles PrintDocument1.PrintPage
        changelongpaper()
        Dim f5 As New Font("Calibri", 6, FontStyle.Regular)
        Dim f8 As New Font("Calibri", 8, FontStyle.Regular)
        Dim f10 As New Font("Calibri", 9, FontStyle.Regular)
        Dim f10b As New Font("Calibri", 10, FontStyle.Bold)
        Dim f14 As New Font("Calibri", 12, FontStyle.Bold)

        Dim leftmargin As Integer = PrintDocument1.DefaultPageSettings.Margins.Left
        Dim centermargin As Integer = PrintDocument1.DefaultPageSettings.PaperSize.Width / 2
        Dim rightmargin As Integer = PrintDocument1.DefaultPageSettings.PaperSize.Width

        'font alignment
        Dim right As New StringFormat
        Dim center As New StringFormat

        right.Alignment = StringAlignment.Far
        center.Alignment = StringAlignment.Center

        Dim line As String
        line = "****************************************************************************"

        'range from top
        e.Graphics.DrawString("POS Cashier", f14, Brushes.Black, centermargin, 5, center)
        e.Graphics.DrawString("Palanginan Iba Zambales PH", f8, Brushes.Black, centermargin, 25, center)
        e.Graphics.DrawString("Contact No. 09610090120", f8, Brushes.Black, centermargin, 40, center)

        e.Graphics.DrawString("Trans ID", f5, Brushes.Black, 0, 60)
        e.Graphics.DrawString(":", f5, Brushes.Black, 50, 60)
        e.Graphics.DrawString("DRW8555RE", f5, Brushes.Black, 70, 60)

        e.Graphics.DrawString("Cashier", f5, Brushes.Black, 0, 75)
        e.Graphics.DrawString(":", f5, Brushes.Black, 50, 75)
        e.Graphics.DrawString(txtCashier.Text, f5, Brushes.Black, 70, 75)

        e.Graphics.DrawString("Trans Date", f5, Brushes.Black, 0, 90)
        e.Graphics.DrawString(":", f5, Brushes.Black, 50, 90)
        e.Graphics.DrawString(d1.Value, f5, Brushes.Black, 70, 90)

        e.Graphics.DrawString(line, f8, Brushes.Black, 0, 100)

        Dim height As Integer 'DGV Position
        Dim i As Long
        dgtemp.AllowUserToAddRows = False
        'If DataGridView1.CurrentCell.Value Is Nothing Then
        '    Exit Sub
        'Else
        For row As Integer = 0 To dgtemp.RowCount - 1
            height += 15
            e.Graphics.DrawString(dgtemp.Rows(row).Cells(2).Value.ToString, f10, Brushes.Black, 0, 100 + height)
            e.Graphics.DrawString(dgtemp.Rows(row).Cells(0).Value.ToString, f10, Brushes.Black, 25, 100 + height)

            i = dgtemp.Rows(row).Cells(4).Value
            dgtemp.Rows(row).Cells(4).Value = FormatCurrency(i)
            e.Graphics.DrawString(dgtemp.Rows(row).Cells(4).Value.ToString, f10, Brushes.Black, rightmargin, 100 + height, right)
        Next
        'End If

        Dim height2 As Integer
        height2 = 110 + height
        e.Graphics.DrawString(line, f8, Brushes.Black, 0, height2)
        e.Graphics.DrawString("Total: " & lblDisplay.Text, f10b, Brushes.Black, rightmargin, 10 + height2, right)
        e.Graphics.DrawString("Amount: " & lblDisplay.Text, f10b, Brushes.Black, rightmargin, 24 + height2, right)
        e.Graphics.DrawString("Change: " & lblchange.Text, f10b, Brushes.Black, rightmargin, 38 + height2, right)
        e.Graphics.DrawString(txtQ.Text, f10b, Brushes.Black, 0, 10 + height2)
        'e.Graphics.DrawString("VAT: " & lblVAT.Text, f8, Brushes.Black, rightmargin, 60 + height2, right)
        'e.Graphics.DrawString(line, f8, Brushes.Black, 0, 51 + height2)
        e.Graphics.DrawString("~ Thank you for comming ~", f8, Brushes.Black, centermargin, 145 + height2, center)
        e.Graphics.DrawString("~ POS Cashier ~", f8, Brushes.Black, centermargin, 160 + height2, center)
    End Sub
    Private Sub PRINTRECIEPTToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles PRINTRECIEPTToolStripMenuItem.Click
        changelongpaper()
        PrintPreviewControl1.Document = PrintDocument1
    End Sub
End Class