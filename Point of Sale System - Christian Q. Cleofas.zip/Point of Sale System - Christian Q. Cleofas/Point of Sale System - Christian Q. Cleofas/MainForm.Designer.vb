﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class MainForm
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Me.GunaElipse1 = New Guna.UI.WinForms.GunaElipse(Me.components)
        Me.Panel3 = New System.Windows.Forms.Panel()
        Me.dtTime = New Guna.UI2.WinForms.Guna2DateTimePicker()
        Me.MenuStrip1 = New System.Windows.Forms.MenuStrip()
        Me.FileToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.LogoutUserToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ReportViewToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.SalesReportToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.UserReportToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.StockReportToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.CashierToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.NewUserToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.InventoryToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.Panel1 = New System.Windows.Forms.Panel()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.lblLoginAs = New System.Windows.Forms.Label()
        Me.Panel3.SuspendLayout()
        Me.MenuStrip1.SuspendLayout()
        Me.Panel1.SuspendLayout()
        Me.SuspendLayout()
        '
        'GunaElipse1
        '
        Me.GunaElipse1.Radius = 0
        Me.GunaElipse1.TargetControl = Me
        '
        'Panel3
        '
        Me.Panel3.Controls.Add(Me.dtTime)
        Me.Panel3.Controls.Add(Me.MenuStrip1)
        Me.Panel3.Dock = System.Windows.Forms.DockStyle.Top
        Me.Panel3.Location = New System.Drawing.Point(0, 158)
        Me.Panel3.Name = "Panel3"
        Me.Panel3.Size = New System.Drawing.Size(1368, 52)
        Me.Panel3.TabIndex = 31
        '
        'dtTime
        '
        Me.dtTime.BorderRadius = 1
        Me.dtTime.BorderThickness = 1
        Me.dtTime.CheckedState.Parent = Me.dtTime
        Me.dtTime.FillColor = System.Drawing.Color.White
        Me.dtTime.Font = New System.Drawing.Font("Segoe UI", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.dtTime.ForeColor = System.Drawing.Color.FromArgb(CType(CType(64, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.dtTime.Format = System.Windows.Forms.DateTimePickerFormat.[Long]
        Me.dtTime.HoverState.Parent = Me.dtTime
        Me.dtTime.Location = New System.Drawing.Point(1078, 7)
        Me.dtTime.MaxDate = New Date(9998, 12, 31, 0, 0, 0, 0)
        Me.dtTime.MinDate = New Date(1753, 1, 1, 0, 0, 0, 0)
        Me.dtTime.Name = "dtTime"
        Me.dtTime.ShadowDecoration.Parent = Me.dtTime
        Me.dtTime.Size = New System.Drawing.Size(274, 34)
        Me.dtTime.TabIndex = 33
        Me.dtTime.Value = New Date(2021, 5, 15, 20, 7, 31, 573)
        '
        'MenuStrip1
        '
        Me.MenuStrip1.Dock = System.Windows.Forms.DockStyle.Fill
        Me.MenuStrip1.Font = New System.Drawing.Font("Segoe UI Semibold", 14.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.MenuStrip1.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.FileToolStripMenuItem, Me.ReportViewToolStripMenuItem, Me.CashierToolStripMenuItem, Me.NewUserToolStripMenuItem, Me.InventoryToolStripMenuItem})
        Me.MenuStrip1.Location = New System.Drawing.Point(0, 0)
        Me.MenuStrip1.Name = "MenuStrip1"
        Me.MenuStrip1.Size = New System.Drawing.Size(1368, 52)
        Me.MenuStrip1.TabIndex = 32
        Me.MenuStrip1.Text = "MenuStrip1"
        '
        'FileToolStripMenuItem
        '
        Me.FileToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.LogoutUserToolStripMenuItem})
        Me.FileToolStripMenuItem.Name = "FileToolStripMenuItem"
        Me.FileToolStripMenuItem.Size = New System.Drawing.Size(54, 48)
        Me.FileToolStripMenuItem.Text = "File"
        '
        'LogoutUserToolStripMenuItem
        '
        Me.LogoutUserToolStripMenuItem.Name = "LogoutUserToolStripMenuItem"
        Me.LogoutUserToolStripMenuItem.Size = New System.Drawing.Size(194, 30)
        Me.LogoutUserToolStripMenuItem.Text = "Logout / Exit"
        '
        'ReportViewToolStripMenuItem
        '
        Me.ReportViewToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.SalesReportToolStripMenuItem, Me.UserReportToolStripMenuItem, Me.StockReportToolStripMenuItem})
        Me.ReportViewToolStripMenuItem.Name = "ReportViewToolStripMenuItem"
        Me.ReportViewToolStripMenuItem.ShortcutKeyDisplayString = "Escape"
        Me.ReportViewToolStripMenuItem.ShortcutKeys = System.Windows.Forms.Keys.F1
        Me.ReportViewToolStripMenuItem.Size = New System.Drawing.Size(128, 48)
        Me.ReportViewToolStripMenuItem.Text = "Report View"
        '
        'SalesReportToolStripMenuItem
        '
        Me.SalesReportToolStripMenuItem.Name = "SalesReportToolStripMenuItem"
        Me.SalesReportToolStripMenuItem.Size = New System.Drawing.Size(193, 30)
        Me.SalesReportToolStripMenuItem.Text = "Sales Report"
        '
        'UserReportToolStripMenuItem
        '
        Me.UserReportToolStripMenuItem.Name = "UserReportToolStripMenuItem"
        Me.UserReportToolStripMenuItem.Size = New System.Drawing.Size(193, 30)
        Me.UserReportToolStripMenuItem.Text = "User Report"
        '
        'StockReportToolStripMenuItem
        '
        Me.StockReportToolStripMenuItem.Name = "StockReportToolStripMenuItem"
        Me.StockReportToolStripMenuItem.Size = New System.Drawing.Size(193, 30)
        Me.StockReportToolStripMenuItem.Text = "Stock Report"
        '
        'CashierToolStripMenuItem
        '
        Me.CashierToolStripMenuItem.Name = "CashierToolStripMenuItem"
        Me.CashierToolStripMenuItem.Size = New System.Drawing.Size(87, 48)
        Me.CashierToolStripMenuItem.Text = "Cashier"
        '
        'NewUserToolStripMenuItem
        '
        Me.NewUserToolStripMenuItem.Name = "NewUserToolStripMenuItem"
        Me.NewUserToolStripMenuItem.ShortcutKeyDisplayString = "Del"
        Me.NewUserToolStripMenuItem.ShortcutKeys = System.Windows.Forms.Keys.Delete
        Me.NewUserToolStripMenuItem.Size = New System.Drawing.Size(106, 48)
        Me.NewUserToolStripMenuItem.Text = "New User"
        '
        'InventoryToolStripMenuItem
        '
        Me.InventoryToolStripMenuItem.Name = "InventoryToolStripMenuItem"
        Me.InventoryToolStripMenuItem.Size = New System.Drawing.Size(108, 48)
        Me.InventoryToolStripMenuItem.Text = "Inventory"
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Font = New System.Drawing.Font("Segoe UI Black", 48.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label3.ForeColor = System.Drawing.Color.White
        Me.Label3.Location = New System.Drawing.Point(157, 36)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(1079, 86)
        Me.Label3.TabIndex = 4
        Me.Label3.Text = "Point of Sales Main Form System"
        '
        'Panel1
        '
        Me.Panel1.BackColor = System.Drawing.Color.FromArgb(CType(CType(64, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.Panel1.Controls.Add(Me.Label3)
        Me.Panel1.Dock = System.Windows.Forms.DockStyle.Top
        Me.Panel1.Location = New System.Drawing.Point(0, 0)
        Me.Panel1.Name = "Panel1"
        Me.Panel1.Size = New System.Drawing.Size(1368, 158)
        Me.Panel1.TabIndex = 0
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Font = New System.Drawing.Font("Segoe UI", 48.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.ForeColor = System.Drawing.Color.White
        Me.Label1.Location = New System.Drawing.Point(63, 362)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(1227, 86)
        Me.Label1.TabIndex = 5
        Me.Label1.Text = "Welcome to Point of Sales Main System"
        '
        'lblLoginAs
        '
        Me.lblLoginAs.AutoSize = True
        Me.lblLoginAs.Font = New System.Drawing.Font("Segoe UI", 48.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblLoginAs.ForeColor = System.Drawing.Color.White
        Me.lblLoginAs.Location = New System.Drawing.Point(558, 484)
        Me.lblLoginAs.Name = "lblLoginAs"
        Me.lblLoginAs.Size = New System.Drawing.Size(0, 86)
        Me.lblLoginAs.TabIndex = 32
        '
        'MainForm
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.Color.FromArgb(CType(CType(64, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.ClientSize = New System.Drawing.Size(1368, 728)
        Me.Controls.Add(Me.lblLoginAs)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.Panel3)
        Me.Controls.Add(Me.Panel1)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None
        Me.Name = "MainForm"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "MainForm"
        Me.Panel3.ResumeLayout(False)
        Me.Panel3.PerformLayout()
        Me.MenuStrip1.ResumeLayout(False)
        Me.MenuStrip1.PerformLayout()
        Me.Panel1.ResumeLayout(False)
        Me.Panel1.PerformLayout()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents GunaElipse1 As Guna.UI.WinForms.GunaElipse
    Friend WithEvents Panel3 As System.Windows.Forms.Panel
    Friend WithEvents MenuStrip1 As System.Windows.Forms.MenuStrip
    Friend WithEvents Panel1 As System.Windows.Forms.Panel
    Friend WithEvents Label3 As System.Windows.Forms.Label
    Friend WithEvents ReportViewToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents CashierToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents NewUserToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents FileToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents InventoryToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents LogoutUserToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents SalesReportToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents UserReportToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents StockReportToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents lblLoginAs As System.Windows.Forms.Label
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents dtTime As Guna.UI2.WinForms.Guna2DateTimePicker
End Class
