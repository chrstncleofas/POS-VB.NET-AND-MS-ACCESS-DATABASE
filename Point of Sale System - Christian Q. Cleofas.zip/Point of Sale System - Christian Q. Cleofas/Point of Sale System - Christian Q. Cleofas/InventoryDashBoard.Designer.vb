﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class InventoryDashBoard
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(InventoryDashBoard))
        Dim DataGridViewCellStyle9 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle10 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle11 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle12 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Me.GunaElipse1 = New Guna.UI.WinForms.GunaElipse(Me.components)
        Me.Panel1 = New System.Windows.Forms.Panel()
        Me.Label19 = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.btnHome = New Guna.UI.WinForms.GunaButton()
        Me.btnBack = New Guna.UI.WinForms.GunaButton()
        Me.btnEditing = New Guna.UI.WinForms.GunaButton()
        Me.btnAddProduct = New Guna.UI.WinForms.GunaButton()
        Me.btnStock = New Guna.UI.WinForms.GunaButton()
        Me.OpenFileDialog1 = New System.Windows.Forms.OpenFileDialog()
        Me.btnSP = New Guna.UI.WinForms.GunaAdvenceTileButton()
        Me.btnAP = New Guna.UI.WinForms.GunaAdvenceTileButton()
        Me.btnEP = New Guna.UI.WinForms.GunaAdvenceTileButton()
        Me.Panel2 = New System.Windows.Forms.Panel()
        Me.Label14 = New System.Windows.Forms.Label()
        Me.pnEditPage = New System.Windows.Forms.Panel()
        Me.btnEdit = New Guna.UI.WinForms.GunaButton()
        Me.Panel3 = New System.Windows.Forms.Panel()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.Label11 = New System.Windows.Forms.Label()
        Me.SellingPrice = New Guna.UI.WinForms.GunaTextBox()
        Me.btnUpdate = New Guna.UI.WinForms.GunaButton()
        Me.Label12 = New System.Windows.Forms.Label()
        Me.BuyingPrice = New Guna.UI.WinForms.GunaTextBox()
        Me.Quantity = New Guna.UI2.WinForms.Guna2NumericUpDown()
        Me.Description = New Guna.UI.WinForms.GunaTextBox()
        Me.Label13 = New System.Windows.Forms.Label()
        Me.Label15 = New System.Windows.Forms.Label()
        Me.Label17 = New System.Windows.Forms.Label()
        Me.ProductID = New Guna.UI.WinForms.GunaTextBox()
        Me.Images = New System.Windows.Forms.PictureBox()
        Me.pnStock = New System.Windows.Forms.Panel()
        Me.btnPrint = New Guna.UI.WinForms.GunaButton()
        Me.Images1 = New System.Windows.Forms.PictureBox()
        Me.Panel4 = New System.Windows.Forms.Panel()
        Me.Label18 = New System.Windows.Forms.Label()
        Me.btnC = New Guna.UI.WinForms.GunaButton()
        Me.btnSearch = New Guna.UI.WinForms.GunaButton()
        Me.txtSearch = New Guna.UI.WinForms.GunaTextBox()
        Me.btnPrev = New Guna.UI.WinForms.GunaCircleButton()
        Me.btnFirst = New Guna.UI.WinForms.GunaCircleButton()
        Me.btnLast = New Guna.UI.WinForms.GunaCircleButton()
        Me.btnNext = New Guna.UI.WinForms.GunaCircleButton()
        Me.btnDelete = New Guna.UI.WinForms.GunaButton()
        Me.dgStock = New Guna.UI.WinForms.GunaDataGridView()
        Me.pnAddProduct = New System.Windows.Forms.Panel()
        Me.Panel5 = New System.Windows.Forms.Panel()
        Me.Label16 = New System.Windows.Forms.Label()
        Me.Label8 = New System.Windows.Forms.Label()
        Me.txtSellingPrice = New Guna.UI.WinForms.GunaTextBox()
        Me.btnAdd = New Guna.UI.WinForms.GunaButton()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.txtBuyingPrice = New Guna.UI.WinForms.GunaTextBox()
        Me.txtProductQuan = New Guna.UI2.WinForms.Guna2NumericUpDown()
        Me.txtDescription = New Guna.UI.WinForms.GunaTextBox()
        Me.Label10 = New System.Windows.Forms.Label()
        Me.txtCategory = New Guna.UI.WinForms.GunaTextBox()
        Me.Label7 = New System.Windows.Forms.Label()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.txtProductName = New Guna.UI.WinForms.GunaTextBox()
        Me.Label9 = New System.Windows.Forms.Label()
        Me.txtProductID = New Guna.UI.WinForms.GunaTextBox()
        Me.btnUpload = New Guna.UI.WinForms.GunaButton()
        Me.pdID = New System.Windows.Forms.PictureBox()
        Me.SaveFileDialog1 = New System.Windows.Forms.SaveFileDialog()
        Me.d1 = New System.Windows.Forms.DateTimePicker()
        Me.Panel1.SuspendLayout()
        Me.Panel2.SuspendLayout()
        Me.pnEditPage.SuspendLayout()
        Me.Panel3.SuspendLayout()
        CType(Me.Quantity, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.Images, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.pnStock.SuspendLayout()
        CType(Me.Images1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.Panel4.SuspendLayout()
        CType(Me.dgStock, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.pnAddProduct.SuspendLayout()
        Me.Panel5.SuspendLayout()
        CType(Me.txtProductQuan, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.pdID, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'GunaElipse1
        '
        Me.GunaElipse1.Radius = 0
        Me.GunaElipse1.TargetControl = Me
        '
        'Panel1
        '
        Me.Panel1.BackColor = System.Drawing.Color.FromArgb(CType(CType(64, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.Panel1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Panel1.Controls.Add(Me.Label19)
        Me.Panel1.Controls.Add(Me.Label2)
        Me.Panel1.Controls.Add(Me.btnHome)
        Me.Panel1.Controls.Add(Me.btnBack)
        Me.Panel1.Controls.Add(Me.btnEditing)
        Me.Panel1.Controls.Add(Me.btnAddProduct)
        Me.Panel1.Controls.Add(Me.btnStock)
        Me.Panel1.Dock = System.Windows.Forms.DockStyle.Left
        Me.Panel1.Location = New System.Drawing.Point(0, 0)
        Me.Panel1.Name = "Panel1"
        Me.Panel1.Size = New System.Drawing.Size(202, 728)
        Me.Panel1.TabIndex = 1
        '
        'Label19
        '
        Me.Label19.AutoSize = True
        Me.Label19.Font = New System.Drawing.Font("Segoe UI", 14.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label19.ForeColor = System.Drawing.Color.White
        Me.Label19.Location = New System.Drawing.Point(62, 81)
        Me.Label19.Name = "Label19"
        Me.Label19.Size = New System.Drawing.Size(75, 25)
        Me.Label19.TabIndex = 10
        Me.Label19.Text = "System"
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Font = New System.Drawing.Font("Segoe UI", 14.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label2.ForeColor = System.Drawing.Color.White
        Me.Label2.Location = New System.Drawing.Point(9, 51)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(185, 25)
        Me.Label2.TabIndex = 9
        Me.Label2.Text = "Stock Management"
        '
        'btnHome
        '
        Me.btnHome.AnimationHoverSpeed = 0.07!
        Me.btnHome.AnimationSpeed = 0.03!
        Me.btnHome.BaseColor = System.Drawing.Color.FromArgb(CType(CType(64, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.btnHome.BorderColor = System.Drawing.Color.Black
        Me.btnHome.Cursor = System.Windows.Forms.Cursors.Hand
        Me.btnHome.DialogResult = System.Windows.Forms.DialogResult.None
        Me.btnHome.FocusedColor = System.Drawing.Color.Empty
        Me.btnHome.Font = New System.Drawing.Font("Segoe UI", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnHome.ForeColor = System.Drawing.Color.White
        Me.btnHome.Image = CType(resources.GetObject("btnHome.Image"), System.Drawing.Image)
        Me.btnHome.ImageSize = New System.Drawing.Size(25, 25)
        Me.btnHome.Location = New System.Drawing.Point(3, 142)
        Me.btnHome.Name = "btnHome"
        Me.btnHome.OnHoverBaseColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.btnHome.OnHoverBorderColor = System.Drawing.Color.Black
        Me.btnHome.OnHoverForeColor = System.Drawing.Color.White
        Me.btnHome.OnHoverImage = Nothing
        Me.btnHome.OnPressedColor = System.Drawing.Color.Black
        Me.btnHome.Padding = New System.Windows.Forms.Padding(15, 0, 0, 0)
        Me.btnHome.Size = New System.Drawing.Size(196, 55)
        Me.btnHome.TabIndex = 4
        Me.btnHome.Text = "   Home Page"
        '
        'btnBack
        '
        Me.btnBack.AnimationHoverSpeed = 0.07!
        Me.btnBack.AnimationSpeed = 0.03!
        Me.btnBack.BaseColor = System.Drawing.Color.FromArgb(CType(CType(64, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.btnBack.BorderColor = System.Drawing.Color.Black
        Me.btnBack.Cursor = System.Windows.Forms.Cursors.Hand
        Me.btnBack.DialogResult = System.Windows.Forms.DialogResult.None
        Me.btnBack.FocusedColor = System.Drawing.Color.Empty
        Me.btnBack.Font = New System.Drawing.Font("Segoe UI", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnBack.ForeColor = System.Drawing.Color.White
        Me.btnBack.Image = CType(resources.GetObject("btnBack.Image"), System.Drawing.Image)
        Me.btnBack.ImageSize = New System.Drawing.Size(25, 25)
        Me.btnBack.Location = New System.Drawing.Point(2, 668)
        Me.btnBack.Name = "btnBack"
        Me.btnBack.OnHoverBaseColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.btnBack.OnHoverBorderColor = System.Drawing.Color.Black
        Me.btnBack.OnHoverForeColor = System.Drawing.Color.White
        Me.btnBack.OnHoverImage = Nothing
        Me.btnBack.OnPressedColor = System.Drawing.Color.Black
        Me.btnBack.Padding = New System.Windows.Forms.Padding(15, 0, 0, 0)
        Me.btnBack.Size = New System.Drawing.Size(196, 55)
        Me.btnBack.TabIndex = 3
        Me.btnBack.Text = "Back to Main Form"
        '
        'btnEditing
        '
        Me.btnEditing.AnimationHoverSpeed = 0.07!
        Me.btnEditing.AnimationSpeed = 0.03!
        Me.btnEditing.BaseColor = System.Drawing.Color.FromArgb(CType(CType(64, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.btnEditing.BorderColor = System.Drawing.Color.Black
        Me.btnEditing.Cursor = System.Windows.Forms.Cursors.Hand
        Me.btnEditing.DialogResult = System.Windows.Forms.DialogResult.None
        Me.btnEditing.FocusedColor = System.Drawing.Color.Empty
        Me.btnEditing.Font = New System.Drawing.Font("Segoe UI", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnEditing.ForeColor = System.Drawing.Color.White
        Me.btnEditing.Image = CType(resources.GetObject("btnEditing.Image"), System.Drawing.Image)
        Me.btnEditing.ImageSize = New System.Drawing.Size(25, 25)
        Me.btnEditing.Location = New System.Drawing.Point(3, 321)
        Me.btnEditing.Name = "btnEditing"
        Me.btnEditing.OnHoverBaseColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.btnEditing.OnHoverBorderColor = System.Drawing.Color.Black
        Me.btnEditing.OnHoverForeColor = System.Drawing.Color.White
        Me.btnEditing.OnHoverImage = Nothing
        Me.btnEditing.OnPressedColor = System.Drawing.Color.Black
        Me.btnEditing.Padding = New System.Windows.Forms.Padding(15, 0, 0, 0)
        Me.btnEditing.Size = New System.Drawing.Size(196, 55)
        Me.btnEditing.TabIndex = 2
        Me.btnEditing.Text = "   Edit Product"
        '
        'btnAddProduct
        '
        Me.btnAddProduct.AnimationHoverSpeed = 0.07!
        Me.btnAddProduct.AnimationSpeed = 0.03!
        Me.btnAddProduct.BaseColor = System.Drawing.Color.FromArgb(CType(CType(64, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.btnAddProduct.BorderColor = System.Drawing.Color.Black
        Me.btnAddProduct.Cursor = System.Windows.Forms.Cursors.Hand
        Me.btnAddProduct.DialogResult = System.Windows.Forms.DialogResult.None
        Me.btnAddProduct.FocusedColor = System.Drawing.Color.Empty
        Me.btnAddProduct.Font = New System.Drawing.Font("Segoe UI", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnAddProduct.ForeColor = System.Drawing.Color.White
        Me.btnAddProduct.Image = CType(resources.GetObject("btnAddProduct.Image"), System.Drawing.Image)
        Me.btnAddProduct.ImageSize = New System.Drawing.Size(25, 25)
        Me.btnAddProduct.Location = New System.Drawing.Point(3, 260)
        Me.btnAddProduct.Name = "btnAddProduct"
        Me.btnAddProduct.OnHoverBaseColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.btnAddProduct.OnHoverBorderColor = System.Drawing.Color.Black
        Me.btnAddProduct.OnHoverForeColor = System.Drawing.Color.White
        Me.btnAddProduct.OnHoverImage = Nothing
        Me.btnAddProduct.OnPressedColor = System.Drawing.Color.Black
        Me.btnAddProduct.Padding = New System.Windows.Forms.Padding(15, 0, 0, 0)
        Me.btnAddProduct.Size = New System.Drawing.Size(196, 55)
        Me.btnAddProduct.TabIndex = 1
        Me.btnAddProduct.Text = "   Add Product"
        '
        'btnStock
        '
        Me.btnStock.AnimationHoverSpeed = 0.07!
        Me.btnStock.AnimationSpeed = 0.03!
        Me.btnStock.BaseColor = System.Drawing.Color.FromArgb(CType(CType(64, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.btnStock.BorderColor = System.Drawing.Color.Black
        Me.btnStock.Cursor = System.Windows.Forms.Cursors.Hand
        Me.btnStock.DialogResult = System.Windows.Forms.DialogResult.None
        Me.btnStock.FocusedColor = System.Drawing.Color.Empty
        Me.btnStock.Font = New System.Drawing.Font("Segoe UI", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnStock.ForeColor = System.Drawing.Color.White
        Me.btnStock.Image = CType(resources.GetObject("btnStock.Image"), System.Drawing.Image)
        Me.btnStock.ImageSize = New System.Drawing.Size(25, 25)
        Me.btnStock.Location = New System.Drawing.Point(3, 203)
        Me.btnStock.Name = "btnStock"
        Me.btnStock.OnHoverBaseColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.btnStock.OnHoverBorderColor = System.Drawing.Color.Black
        Me.btnStock.OnHoverForeColor = System.Drawing.Color.White
        Me.btnStock.OnHoverImage = Nothing
        Me.btnStock.OnPressedColor = System.Drawing.Color.Black
        Me.btnStock.Padding = New System.Windows.Forms.Padding(15, 0, 0, 0)
        Me.btnStock.Size = New System.Drawing.Size(196, 55)
        Me.btnStock.TabIndex = 0
        Me.btnStock.Text = "   Stock Page"
        '
        'OpenFileDialog1
        '
        Me.OpenFileDialog1.FileName = "OpenFileDialog1"
        '
        'btnSP
        '
        Me.btnSP.AnimationHoverSpeed = 0.07!
        Me.btnSP.AnimationSpeed = 0.03!
        Me.btnSP.BaseColor = System.Drawing.Color.FromArgb(CType(CType(64, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.btnSP.BorderColor = System.Drawing.Color.Black
        Me.btnSP.CheckedBaseColor = System.Drawing.Color.Gray
        Me.btnSP.CheckedBorderColor = System.Drawing.Color.Black
        Me.btnSP.CheckedForeColor = System.Drawing.Color.White
        Me.btnSP.CheckedImage = CType(resources.GetObject("btnSP.CheckedImage"), System.Drawing.Image)
        Me.btnSP.CheckedLineColor = System.Drawing.Color.DimGray
        Me.btnSP.Cursor = System.Windows.Forms.Cursors.Hand
        Me.btnSP.DialogResult = System.Windows.Forms.DialogResult.None
        Me.btnSP.FocusedColor = System.Drawing.Color.Empty
        Me.btnSP.Font = New System.Drawing.Font("Segoe UI", 21.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnSP.ForeColor = System.Drawing.Color.White
        Me.btnSP.Image = CType(resources.GetObject("btnSP.Image"), System.Drawing.Image)
        Me.btnSP.ImageSize = New System.Drawing.Size(60, 60)
        Me.btnSP.LineColor = System.Drawing.Color.FromArgb(CType(CType(66, Byte), Integer), CType(CType(58, Byte), Integer), CType(CType(170, Byte), Integer))
        Me.btnSP.Location = New System.Drawing.Point(342, 173)
        Me.btnSP.Name = "btnSP"
        Me.btnSP.OnHoverBaseColor = System.Drawing.Color.Maroon
        Me.btnSP.OnHoverBorderColor = System.Drawing.Color.Black
        Me.btnSP.OnHoverForeColor = System.Drawing.Color.White
        Me.btnSP.OnHoverImage = Nothing
        Me.btnSP.OnHoverLineColor = System.Drawing.Color.FromArgb(CType(CType(66, Byte), Integer), CType(CType(58, Byte), Integer), CType(CType(170, Byte), Integer))
        Me.btnSP.OnPressedColor = System.Drawing.Color.Black
        Me.btnSP.Size = New System.Drawing.Size(301, 207)
        Me.btnSP.TabIndex = 8
        Me.btnSP.Text = "Stock Page"
        '
        'btnAP
        '
        Me.btnAP.AnimationHoverSpeed = 0.07!
        Me.btnAP.AnimationSpeed = 0.03!
        Me.btnAP.BaseColor = System.Drawing.Color.FromArgb(CType(CType(64, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.btnAP.BorderColor = System.Drawing.Color.Black
        Me.btnAP.CheckedBaseColor = System.Drawing.Color.Gray
        Me.btnAP.CheckedBorderColor = System.Drawing.Color.Black
        Me.btnAP.CheckedForeColor = System.Drawing.Color.White
        Me.btnAP.CheckedImage = CType(resources.GetObject("btnAP.CheckedImage"), System.Drawing.Image)
        Me.btnAP.CheckedLineColor = System.Drawing.Color.DimGray
        Me.btnAP.Cursor = System.Windows.Forms.Cursors.Hand
        Me.btnAP.DialogResult = System.Windows.Forms.DialogResult.None
        Me.btnAP.FocusedColor = System.Drawing.Color.Empty
        Me.btnAP.Font = New System.Drawing.Font("Segoe UI", 21.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnAP.ForeColor = System.Drawing.Color.White
        Me.btnAP.Image = CType(resources.GetObject("btnAP.Image"), System.Drawing.Image)
        Me.btnAP.ImageSize = New System.Drawing.Size(60, 60)
        Me.btnAP.LineColor = System.Drawing.Color.FromArgb(CType(CType(66, Byte), Integer), CType(CType(58, Byte), Integer), CType(CType(170, Byte), Integer))
        Me.btnAP.Location = New System.Drawing.Point(650, 173)
        Me.btnAP.Name = "btnAP"
        Me.btnAP.OnHoverBaseColor = System.Drawing.Color.Maroon
        Me.btnAP.OnHoverBorderColor = System.Drawing.Color.Black
        Me.btnAP.OnHoverForeColor = System.Drawing.Color.White
        Me.btnAP.OnHoverImage = Nothing
        Me.btnAP.OnHoverLineColor = System.Drawing.Color.FromArgb(CType(CType(66, Byte), Integer), CType(CType(58, Byte), Integer), CType(CType(170, Byte), Integer))
        Me.btnAP.OnPressedColor = System.Drawing.Color.Black
        Me.btnAP.Size = New System.Drawing.Size(301, 207)
        Me.btnAP.TabIndex = 9
        Me.btnAP.Text = "Add Item"
        '
        'btnEP
        '
        Me.btnEP.AnimationHoverSpeed = 0.07!
        Me.btnEP.AnimationSpeed = 0.03!
        Me.btnEP.BaseColor = System.Drawing.Color.FromArgb(CType(CType(64, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.btnEP.BorderColor = System.Drawing.Color.Black
        Me.btnEP.CheckedBaseColor = System.Drawing.Color.Gray
        Me.btnEP.CheckedBorderColor = System.Drawing.Color.Black
        Me.btnEP.CheckedForeColor = System.Drawing.Color.White
        Me.btnEP.CheckedImage = CType(resources.GetObject("btnEP.CheckedImage"), System.Drawing.Image)
        Me.btnEP.CheckedLineColor = System.Drawing.Color.DimGray
        Me.btnEP.Cursor = System.Windows.Forms.Cursors.Hand
        Me.btnEP.DialogResult = System.Windows.Forms.DialogResult.None
        Me.btnEP.FocusedColor = System.Drawing.Color.Empty
        Me.btnEP.Font = New System.Drawing.Font("Segoe UI", 21.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnEP.ForeColor = System.Drawing.Color.White
        Me.btnEP.Image = CType(resources.GetObject("btnEP.Image"), System.Drawing.Image)
        Me.btnEP.ImageSize = New System.Drawing.Size(60, 60)
        Me.btnEP.LineColor = System.Drawing.Color.FromArgb(CType(CType(66, Byte), Integer), CType(CType(58, Byte), Integer), CType(CType(170, Byte), Integer))
        Me.btnEP.Location = New System.Drawing.Point(961, 173)
        Me.btnEP.Name = "btnEP"
        Me.btnEP.OnHoverBaseColor = System.Drawing.Color.Maroon
        Me.btnEP.OnHoverBorderColor = System.Drawing.Color.Black
        Me.btnEP.OnHoverForeColor = System.Drawing.Color.White
        Me.btnEP.OnHoverImage = Nothing
        Me.btnEP.OnHoverLineColor = System.Drawing.Color.FromArgb(CType(CType(66, Byte), Integer), CType(CType(58, Byte), Integer), CType(CType(170, Byte), Integer))
        Me.btnEP.OnPressedColor = System.Drawing.Color.Black
        Me.btnEP.Size = New System.Drawing.Size(301, 207)
        Me.btnEP.TabIndex = 10
        Me.btnEP.Text = "Editing Item"
        '
        'Panel2
        '
        Me.Panel2.BackColor = System.Drawing.Color.FromArgb(CType(CType(64, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.Panel2.Controls.Add(Me.Label14)
        Me.Panel2.Location = New System.Drawing.Point(220, 51)
        Me.Panel2.Name = "Panel2"
        Me.Panel2.Size = New System.Drawing.Size(1136, 40)
        Me.Panel2.TabIndex = 80
        '
        'Label14
        '
        Me.Label14.AutoSize = True
        Me.Label14.Font = New System.Drawing.Font("Segoe UI", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label14.ForeColor = System.Drawing.Color.White
        Me.Label14.Location = New System.Drawing.Point(15, 11)
        Me.Label14.Name = "Label14"
        Me.Label14.Size = New System.Drawing.Size(116, 17)
        Me.Label14.TabIndex = 80
        Me.Label14.Text = "Stock Home Page"
        '
        'pnEditPage
        '
        Me.pnEditPage.Controls.Add(Me.btnEdit)
        Me.pnEditPage.Controls.Add(Me.Panel3)
        Me.pnEditPage.Controls.Add(Me.Label11)
        Me.pnEditPage.Controls.Add(Me.SellingPrice)
        Me.pnEditPage.Controls.Add(Me.btnUpdate)
        Me.pnEditPage.Controls.Add(Me.Label12)
        Me.pnEditPage.Controls.Add(Me.BuyingPrice)
        Me.pnEditPage.Controls.Add(Me.Quantity)
        Me.pnEditPage.Controls.Add(Me.Description)
        Me.pnEditPage.Controls.Add(Me.Label13)
        Me.pnEditPage.Controls.Add(Me.Label15)
        Me.pnEditPage.Controls.Add(Me.Label17)
        Me.pnEditPage.Controls.Add(Me.ProductID)
        Me.pnEditPage.Controls.Add(Me.Images)
        Me.pnEditPage.Dock = System.Windows.Forms.DockStyle.Fill
        Me.pnEditPage.Location = New System.Drawing.Point(202, 0)
        Me.pnEditPage.Name = "pnEditPage"
        Me.pnEditPage.Size = New System.Drawing.Size(1166, 728)
        Me.pnEditPage.TabIndex = 82
        Me.pnEditPage.Visible = False
        '
        'btnEdit
        '
        Me.btnEdit.AnimationHoverSpeed = 0.07!
        Me.btnEdit.AnimationSpeed = 0.03!
        Me.btnEdit.BackColor = System.Drawing.Color.White
        Me.btnEdit.BaseColor = System.Drawing.Color.FromArgb(CType(CType(64, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.btnEdit.BorderColor = System.Drawing.Color.Black
        Me.btnEdit.Cursor = System.Windows.Forms.Cursors.Hand
        Me.btnEdit.DialogResult = System.Windows.Forms.DialogResult.None
        Me.btnEdit.FocusedColor = System.Drawing.Color.Empty
        Me.btnEdit.Font = New System.Drawing.Font("Segoe UI", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnEdit.ForeColor = System.Drawing.Color.White
        Me.btnEdit.Image = CType(resources.GetObject("btnEdit.Image"), System.Drawing.Image)
        Me.btnEdit.ImageAlign = System.Windows.Forms.HorizontalAlignment.Center
        Me.btnEdit.ImageSize = New System.Drawing.Size(15, 15)
        Me.btnEdit.Location = New System.Drawing.Point(322, 451)
        Me.btnEdit.Name = "btnEdit"
        Me.btnEdit.OnHoverBaseColor = System.Drawing.Color.FromArgb(CType(CType(64, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.btnEdit.OnHoverBorderColor = System.Drawing.Color.Black
        Me.btnEdit.OnHoverForeColor = System.Drawing.Color.White
        Me.btnEdit.OnHoverImage = Nothing
        Me.btnEdit.OnPressedColor = System.Drawing.Color.Black
        Me.btnEdit.Size = New System.Drawing.Size(236, 29)
        Me.btnEdit.TabIndex = 80
        Me.btnEdit.Text = "Upload Image"
        Me.btnEdit.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'Panel3
        '
        Me.Panel3.BackColor = System.Drawing.Color.FromArgb(CType(CType(64, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.Panel3.Controls.Add(Me.Label1)
        Me.Panel3.Location = New System.Drawing.Point(151, 183)
        Me.Panel3.Name = "Panel3"
        Me.Panel3.Size = New System.Drawing.Size(920, 40)
        Me.Panel3.TabIndex = 79
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Font = New System.Drawing.Font("Segoe UI", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.ForeColor = System.Drawing.Color.White
        Me.Label1.Location = New System.Drawing.Point(15, 10)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(123, 17)
        Me.Label1.TabIndex = 80
        Me.Label1.Text = "Stock Editing Page"
        '
        'Label11
        '
        Me.Label11.AutoSize = True
        Me.Label11.Font = New System.Drawing.Font("Segoe UI", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label11.ForeColor = System.Drawing.Color.FromArgb(CType(CType(64, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.Label11.Location = New System.Drawing.Point(595, 400)
        Me.Label11.Name = "Label11"
        Me.Label11.Size = New System.Drawing.Size(96, 17)
        Me.Label11.TabIndex = 78
        Me.Label11.Text = "Selling Price : "
        '
        'SellingPrice
        '
        Me.SellingPrice.BackColor = System.Drawing.Color.Transparent
        Me.SellingPrice.BaseColor = System.Drawing.Color.White
        Me.SellingPrice.BorderColor = System.Drawing.Color.FromArgb(CType(CType(64, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.SellingPrice.BorderSize = 1
        Me.SellingPrice.Cursor = System.Windows.Forms.Cursors.IBeam
        Me.SellingPrice.FocusedBaseColor = System.Drawing.Color.White
        Me.SellingPrice.FocusedBorderColor = System.Drawing.Color.FromArgb(CType(CType(64, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.SellingPrice.FocusedForeColor = System.Drawing.SystemColors.ControlText
        Me.SellingPrice.Font = New System.Drawing.Font("Segoe UI", 9.0!)
        Me.SellingPrice.ForeColor = System.Drawing.Color.FromArgb(CType(CType(64, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.SellingPrice.Location = New System.Drawing.Point(709, 390)
        Me.SellingPrice.Name = "SellingPrice"
        Me.SellingPrice.PasswordChar = Global.Microsoft.VisualBasic.ChrW(0)
        Me.SellingPrice.Radius = 5
        Me.SellingPrice.SelectedText = ""
        Me.SellingPrice.Size = New System.Drawing.Size(196, 34)
        Me.SellingPrice.TabIndex = 77
        '
        'btnUpdate
        '
        Me.btnUpdate.AnimationHoverSpeed = 0.07!
        Me.btnUpdate.AnimationSpeed = 0.03!
        Me.btnUpdate.BackColor = System.Drawing.Color.Transparent
        Me.btnUpdate.BaseColor = System.Drawing.Color.Maroon
        Me.btnUpdate.BorderColor = System.Drawing.Color.Black
        Me.btnUpdate.Cursor = System.Windows.Forms.Cursors.Hand
        Me.btnUpdate.DialogResult = System.Windows.Forms.DialogResult.None
        Me.btnUpdate.FocusedColor = System.Drawing.Color.Empty
        Me.btnUpdate.Font = New System.Drawing.Font("Segoe UI", 14.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnUpdate.ForeColor = System.Drawing.Color.White
        Me.btnUpdate.Image = CType(resources.GetObject("btnUpdate.Image"), System.Drawing.Image)
        Me.btnUpdate.ImageAlign = System.Windows.Forms.HorizontalAlignment.Center
        Me.btnUpdate.ImageSize = New System.Drawing.Size(30, 30)
        Me.btnUpdate.Location = New System.Drawing.Point(151, 508)
        Me.btnUpdate.Name = "btnUpdate"
        Me.btnUpdate.OnHoverBaseColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.btnUpdate.OnHoverBorderColor = System.Drawing.Color.Black
        Me.btnUpdate.OnHoverForeColor = System.Drawing.Color.White
        Me.btnUpdate.OnHoverImage = Nothing
        Me.btnUpdate.OnPressedColor = System.Drawing.Color.Black
        Me.btnUpdate.Size = New System.Drawing.Size(920, 75)
        Me.btnUpdate.TabIndex = 76
        Me.btnUpdate.Text = "Update Product"
        Me.btnUpdate.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'Label12
        '
        Me.Label12.AutoSize = True
        Me.Label12.Font = New System.Drawing.Font("Segoe UI", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label12.ForeColor = System.Drawing.Color.FromArgb(CType(CType(64, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.Label12.Location = New System.Drawing.Point(595, 353)
        Me.Label12.Name = "Label12"
        Me.Label12.Size = New System.Drawing.Size(97, 17)
        Me.Label12.TabIndex = 75
        Me.Label12.Text = "Buying Price : "
        '
        'BuyingPrice
        '
        Me.BuyingPrice.BackColor = System.Drawing.Color.Transparent
        Me.BuyingPrice.BaseColor = System.Drawing.Color.White
        Me.BuyingPrice.BorderColor = System.Drawing.Color.FromArgb(CType(CType(64, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.BuyingPrice.BorderSize = 1
        Me.BuyingPrice.Cursor = System.Windows.Forms.Cursors.IBeam
        Me.BuyingPrice.FocusedBaseColor = System.Drawing.Color.White
        Me.BuyingPrice.FocusedBorderColor = System.Drawing.Color.FromArgb(CType(CType(64, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.BuyingPrice.FocusedForeColor = System.Drawing.SystemColors.ControlText
        Me.BuyingPrice.Font = New System.Drawing.Font("Segoe UI", 9.0!)
        Me.BuyingPrice.ForeColor = System.Drawing.Color.FromArgb(CType(CType(64, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.BuyingPrice.Location = New System.Drawing.Point(708, 344)
        Me.BuyingPrice.Name = "BuyingPrice"
        Me.BuyingPrice.PasswordChar = Global.Microsoft.VisualBasic.ChrW(0)
        Me.BuyingPrice.Radius = 5
        Me.BuyingPrice.SelectedText = ""
        Me.BuyingPrice.Size = New System.Drawing.Size(196, 34)
        Me.BuyingPrice.TabIndex = 74
        '
        'Quantity
        '
        Me.Quantity.BackColor = System.Drawing.Color.White
        Me.Quantity.BorderColor = System.Drawing.Color.FromArgb(CType(CType(64, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.Quantity.BorderRadius = 4
        Me.Quantity.Cursor = System.Windows.Forms.Cursors.IBeam
        Me.Quantity.DisabledState.BorderColor = System.Drawing.Color.FromArgb(CType(CType(208, Byte), Integer), CType(CType(208, Byte), Integer), CType(CType(208, Byte), Integer))
        Me.Quantity.DisabledState.FillColor = System.Drawing.Color.FromArgb(CType(CType(226, Byte), Integer), CType(CType(226, Byte), Integer), CType(CType(226, Byte), Integer))
        Me.Quantity.DisabledState.ForeColor = System.Drawing.Color.FromArgb(CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer))
        Me.Quantity.DisabledState.Parent = Me.Quantity
        Me.Quantity.DisabledState.UpDownButtonFillColor = System.Drawing.Color.FromArgb(CType(CType(177, Byte), Integer), CType(CType(177, Byte), Integer), CType(CType(177, Byte), Integer))
        Me.Quantity.DisabledState.UpDownButtonForeColor = System.Drawing.Color.FromArgb(CType(CType(203, Byte), Integer), CType(CType(203, Byte), Integer), CType(CType(203, Byte), Integer))
        Me.Quantity.FocusedState.BorderColor = System.Drawing.Color.Maroon
        Me.Quantity.FocusedState.ForeColor = System.Drawing.Color.FromArgb(CType(CType(64, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.Quantity.FocusedState.Parent = Me.Quantity
        Me.Quantity.FocusedState.UpDownButtonFillColor = System.Drawing.Color.Maroon
        Me.Quantity.FocusedState.UpDownButtonForeColor = System.Drawing.Color.White
        Me.Quantity.Font = New System.Drawing.Font("Segoe UI", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Quantity.ForeColor = System.Drawing.Color.Black
        Me.Quantity.Location = New System.Drawing.Point(708, 300)
        Me.Quantity.Maximum = New Decimal(New Integer() {1000, 0, 0, 0})
        Me.Quantity.Name = "Quantity"
        Me.Quantity.ShadowDecoration.Color = System.Drawing.Color.White
        Me.Quantity.ShadowDecoration.Parent = Me.Quantity
        Me.Quantity.Size = New System.Drawing.Size(197, 34)
        Me.Quantity.TabIndex = 73
        Me.Quantity.UpDownButtonFillColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer))
        '
        'Description
        '
        Me.Description.BackColor = System.Drawing.Color.Transparent
        Me.Description.BaseColor = System.Drawing.Color.White
        Me.Description.BorderColor = System.Drawing.Color.FromArgb(CType(CType(64, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.Description.BorderSize = 1
        Me.Description.Cursor = System.Windows.Forms.Cursors.IBeam
        Me.Description.FocusedBaseColor = System.Drawing.Color.White
        Me.Description.FocusedBorderColor = System.Drawing.Color.FromArgb(CType(CType(64, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.Description.FocusedForeColor = System.Drawing.SystemColors.ControlText
        Me.Description.Font = New System.Drawing.Font("Segoe UI", 9.0!)
        Me.Description.ForeColor = System.Drawing.Color.FromArgb(CType(CType(64, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.Description.Location = New System.Drawing.Point(709, 438)
        Me.Description.Name = "Description"
        Me.Description.PasswordChar = Global.Microsoft.VisualBasic.ChrW(0)
        Me.Description.Radius = 5
        Me.Description.SelectedText = ""
        Me.Description.Size = New System.Drawing.Size(196, 34)
        Me.Description.TabIndex = 72
        '
        'Label13
        '
        Me.Label13.AutoSize = True
        Me.Label13.Font = New System.Drawing.Font("Segoe UI", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label13.ForeColor = System.Drawing.Color.FromArgb(CType(CType(64, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.Label13.Location = New System.Drawing.Point(595, 447)
        Me.Label13.Name = "Label13"
        Me.Label13.Size = New System.Drawing.Size(91, 17)
        Me.Label13.TabIndex = 71
        Me.Label13.Text = "Description : "
        '
        'Label15
        '
        Me.Label15.AutoSize = True
        Me.Label15.Font = New System.Drawing.Font("Segoe UI", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label15.ForeColor = System.Drawing.Color.FromArgb(CType(CType(64, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.Label15.Location = New System.Drawing.Point(595, 309)
        Me.Label15.Name = "Label15"
        Me.Label15.Size = New System.Drawing.Size(74, 17)
        Me.Label15.TabIndex = 63
        Me.Label15.Text = "Quantity : "
        '
        'Label17
        '
        Me.Label17.AutoSize = True
        Me.Label17.Font = New System.Drawing.Font("Segoe UI", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label17.ForeColor = System.Drawing.Color.FromArgb(CType(CType(64, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.Label17.Location = New System.Drawing.Point(595, 268)
        Me.Label17.Name = "Label17"
        Me.Label17.Size = New System.Drawing.Size(86, 17)
        Me.Label17.TabIndex = 57
        Me.Label17.Text = "Product ID : "
        '
        'ProductID
        '
        Me.ProductID.BackColor = System.Drawing.Color.Transparent
        Me.ProductID.BaseColor = System.Drawing.Color.White
        Me.ProductID.BorderColor = System.Drawing.Color.FromArgb(CType(CType(64, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.ProductID.BorderSize = 1
        Me.ProductID.Cursor = System.Windows.Forms.Cursors.IBeam
        Me.ProductID.FocusedBaseColor = System.Drawing.Color.White
        Me.ProductID.FocusedBorderColor = System.Drawing.Color.FromArgb(CType(CType(64, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.ProductID.FocusedForeColor = System.Drawing.SystemColors.ControlText
        Me.ProductID.Font = New System.Drawing.Font("Segoe UI", 9.0!)
        Me.ProductID.ForeColor = System.Drawing.Color.FromArgb(CType(CType(64, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.ProductID.Location = New System.Drawing.Point(709, 254)
        Me.ProductID.Name = "ProductID"
        Me.ProductID.PasswordChar = Global.Microsoft.VisualBasic.ChrW(0)
        Me.ProductID.Radius = 5
        Me.ProductID.SelectedText = ""
        Me.ProductID.Size = New System.Drawing.Size(196, 34)
        Me.ProductID.TabIndex = 56
        '
        'Images
        '
        Me.Images.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Images.Location = New System.Drawing.Point(322, 261)
        Me.Images.Name = "Images"
        Me.Images.Size = New System.Drawing.Size(236, 184)
        Me.Images.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.Images.TabIndex = 6
        Me.Images.TabStop = False
        '
        'pnStock
        '
        Me.pnStock.BackColor = System.Drawing.Color.White
        Me.pnStock.Controls.Add(Me.btnPrint)
        Me.pnStock.Controls.Add(Me.Images1)
        Me.pnStock.Controls.Add(Me.Panel4)
        Me.pnStock.Controls.Add(Me.btnC)
        Me.pnStock.Controls.Add(Me.btnSearch)
        Me.pnStock.Controls.Add(Me.txtSearch)
        Me.pnStock.Controls.Add(Me.btnPrev)
        Me.pnStock.Controls.Add(Me.btnFirst)
        Me.pnStock.Controls.Add(Me.btnLast)
        Me.pnStock.Controls.Add(Me.btnNext)
        Me.pnStock.Controls.Add(Me.btnDelete)
        Me.pnStock.Controls.Add(Me.dgStock)
        Me.pnStock.Dock = System.Windows.Forms.DockStyle.Fill
        Me.pnStock.Location = New System.Drawing.Point(202, 0)
        Me.pnStock.Name = "pnStock"
        Me.pnStock.Size = New System.Drawing.Size(1166, 728)
        Me.pnStock.TabIndex = 83
        Me.pnStock.Visible = False
        '
        'btnPrint
        '
        Me.btnPrint.AnimationHoverSpeed = 0.07!
        Me.btnPrint.AnimationSpeed = 0.03!
        Me.btnPrint.BackColor = System.Drawing.Color.Transparent
        Me.btnPrint.BaseColor = System.Drawing.Color.White
        Me.btnPrint.BorderColor = System.Drawing.Color.Black
        Me.btnPrint.Cursor = System.Windows.Forms.Cursors.Hand
        Me.btnPrint.DialogResult = System.Windows.Forms.DialogResult.None
        Me.btnPrint.FocusedColor = System.Drawing.Color.Empty
        Me.btnPrint.Font = New System.Drawing.Font("Segoe UI", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnPrint.ForeColor = System.Drawing.Color.FromArgb(CType(CType(64, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.btnPrint.Image = Global.Point_of_Sale_System___Christian_Q.Cleofas.My.Resources.Resources.icons8_export_excel_100
        Me.btnPrint.ImageAlign = System.Windows.Forms.HorizontalAlignment.Center
        Me.btnPrint.ImageSize = New System.Drawing.Size(17, 17)
        Me.btnPrint.Location = New System.Drawing.Point(880, 215)
        Me.btnPrint.Name = "btnPrint"
        Me.btnPrint.OnHoverBaseColor = System.Drawing.Color.White
        Me.btnPrint.OnHoverBorderColor = System.Drawing.Color.Black
        Me.btnPrint.OnHoverForeColor = System.Drawing.Color.FromArgb(CType(CType(64, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.btnPrint.OnHoverImage = Nothing
        Me.btnPrint.OnPressedColor = System.Drawing.Color.Black
        Me.btnPrint.Radius = 5
        Me.btnPrint.Size = New System.Drawing.Size(103, 28)
        Me.btnPrint.TabIndex = 82
        Me.btnPrint.Text = "Printing"
        Me.btnPrint.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'Images1
        '
        Me.Images1.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.Images1.Location = New System.Drawing.Point(19, 85)
        Me.Images1.Name = "Images1"
        Me.Images1.Size = New System.Drawing.Size(243, 164)
        Me.Images1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.Images1.TabIndex = 81
        Me.Images1.TabStop = False
        '
        'Panel4
        '
        Me.Panel4.BackColor = System.Drawing.Color.FromArgb(CType(CType(64, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.Panel4.Controls.Add(Me.Label18)
        Me.Panel4.Location = New System.Drawing.Point(19, 30)
        Me.Panel4.Name = "Panel4"
        Me.Panel4.Size = New System.Drawing.Size(1137, 37)
        Me.Panel4.TabIndex = 80
        '
        'Label18
        '
        Me.Label18.AutoSize = True
        Me.Label18.Font = New System.Drawing.Font("Segoe UI", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label18.ForeColor = System.Drawing.Color.White
        Me.Label18.Location = New System.Drawing.Point(16, 10)
        Me.Label18.Name = "Label18"
        Me.Label18.Size = New System.Drawing.Size(153, 17)
        Me.Label18.TabIndex = 80
        Me.Label18.Text = "Stock Product List Page"
        '
        'btnC
        '
        Me.btnC.AnimationHoverSpeed = 0.07!
        Me.btnC.AnimationSpeed = 0.03!
        Me.btnC.BaseColor = System.Drawing.Color.White
        Me.btnC.BorderColor = System.Drawing.Color.Black
        Me.btnC.Cursor = System.Windows.Forms.Cursors.Hand
        Me.btnC.DialogResult = System.Windows.Forms.DialogResult.None
        Me.btnC.FocusedColor = System.Drawing.Color.Empty
        Me.btnC.Font = New System.Drawing.Font("Segoe UI", 9.0!)
        Me.btnC.ForeColor = System.Drawing.Color.White
        Me.btnC.Image = CType(resources.GetObject("btnC.Image"), System.Drawing.Image)
        Me.btnC.ImageAlign = System.Windows.Forms.HorizontalAlignment.Center
        Me.btnC.ImageSize = New System.Drawing.Size(15, 15)
        Me.btnC.Location = New System.Drawing.Point(465, 221)
        Me.btnC.Name = "btnC"
        Me.btnC.OnHoverBaseColor = System.Drawing.Color.White
        Me.btnC.OnHoverBorderColor = System.Drawing.Color.Black
        Me.btnC.OnHoverForeColor = System.Drawing.Color.White
        Me.btnC.OnHoverImage = Nothing
        Me.btnC.OnPressedColor = System.Drawing.Color.Black
        Me.btnC.Size = New System.Drawing.Size(29, 23)
        Me.btnC.TabIndex = 55
        '
        'btnSearch
        '
        Me.btnSearch.AnimationHoverSpeed = 0.07!
        Me.btnSearch.AnimationSpeed = 0.03!
        Me.btnSearch.BaseColor = System.Drawing.Color.White
        Me.btnSearch.BorderColor = System.Drawing.Color.Black
        Me.btnSearch.Cursor = System.Windows.Forms.Cursors.Hand
        Me.btnSearch.DialogResult = System.Windows.Forms.DialogResult.None
        Me.btnSearch.FocusedColor = System.Drawing.Color.Empty
        Me.btnSearch.Font = New System.Drawing.Font("Segoe UI", 9.0!)
        Me.btnSearch.ForeColor = System.Drawing.Color.White
        Me.btnSearch.Image = CType(resources.GetObject("btnSearch.Image"), System.Drawing.Image)
        Me.btnSearch.ImageAlign = System.Windows.Forms.HorizontalAlignment.Center
        Me.btnSearch.ImageSize = New System.Drawing.Size(15, 15)
        Me.btnSearch.Location = New System.Drawing.Point(490, 221)
        Me.btnSearch.Name = "btnSearch"
        Me.btnSearch.OnHoverBaseColor = System.Drawing.Color.White
        Me.btnSearch.OnHoverBorderColor = System.Drawing.Color.Black
        Me.btnSearch.OnHoverForeColor = System.Drawing.Color.White
        Me.btnSearch.OnHoverImage = Nothing
        Me.btnSearch.OnPressedColor = System.Drawing.Color.Black
        Me.btnSearch.Size = New System.Drawing.Size(29, 23)
        Me.btnSearch.TabIndex = 54
        '
        'txtSearch
        '
        Me.txtSearch.BackColor = System.Drawing.Color.Transparent
        Me.txtSearch.BaseColor = System.Drawing.Color.White
        Me.txtSearch.BorderColor = System.Drawing.Color.Maroon
        Me.txtSearch.BorderSize = 1
        Me.txtSearch.Cursor = System.Windows.Forms.Cursors.IBeam
        Me.txtSearch.FocusedBaseColor = System.Drawing.Color.White
        Me.txtSearch.FocusedBorderColor = System.Drawing.Color.FromArgb(CType(CType(64, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.txtSearch.FocusedForeColor = System.Drawing.SystemColors.ControlText
        Me.txtSearch.Font = New System.Drawing.Font("Segoe UI", 9.0!)
        Me.txtSearch.Location = New System.Drawing.Point(268, 216)
        Me.txtSearch.Name = "txtSearch"
        Me.txtSearch.PasswordChar = Global.Microsoft.VisualBasic.ChrW(0)
        Me.txtSearch.Radius = 5
        Me.txtSearch.SelectedText = ""
        Me.txtSearch.Size = New System.Drawing.Size(255, 33)
        Me.txtSearch.TabIndex = 53
        '
        'btnPrev
        '
        Me.btnPrev.AnimationHoverSpeed = 0.07!
        Me.btnPrev.AnimationSpeed = 0.03!
        Me.btnPrev.BaseColor = System.Drawing.Color.Maroon
        Me.btnPrev.BorderColor = System.Drawing.Color.Black
        Me.btnPrev.DialogResult = System.Windows.Forms.DialogResult.None
        Me.btnPrev.FocusedColor = System.Drawing.Color.Empty
        Me.btnPrev.Font = New System.Drawing.Font("Segoe UI", 9.0!)
        Me.btnPrev.ForeColor = System.Drawing.Color.White
        Me.btnPrev.Image = Nothing
        Me.btnPrev.ImageSize = New System.Drawing.Size(52, 52)
        Me.btnPrev.Location = New System.Drawing.Point(990, 212)
        Me.btnPrev.Name = "btnPrev"
        Me.btnPrev.OnHoverBaseColor = System.Drawing.Color.FromArgb(CType(CType(64, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.btnPrev.OnHoverBorderColor = System.Drawing.Color.Black
        Me.btnPrev.OnHoverForeColor = System.Drawing.Color.White
        Me.btnPrev.OnHoverImage = Nothing
        Me.btnPrev.OnPressedColor = System.Drawing.Color.Black
        Me.btnPrev.Size = New System.Drawing.Size(35, 33)
        Me.btnPrev.TabIndex = 52
        Me.btnPrev.Text = "<<"
        '
        'btnFirst
        '
        Me.btnFirst.AnimationHoverSpeed = 0.07!
        Me.btnFirst.AnimationSpeed = 0.03!
        Me.btnFirst.BaseColor = System.Drawing.Color.Maroon
        Me.btnFirst.BorderColor = System.Drawing.Color.Black
        Me.btnFirst.DialogResult = System.Windows.Forms.DialogResult.None
        Me.btnFirst.FocusedColor = System.Drawing.Color.Empty
        Me.btnFirst.Font = New System.Drawing.Font("Segoe UI", 9.0!)
        Me.btnFirst.ForeColor = System.Drawing.Color.White
        Me.btnFirst.Image = Nothing
        Me.btnFirst.ImageSize = New System.Drawing.Size(52, 52)
        Me.btnFirst.Location = New System.Drawing.Point(1031, 212)
        Me.btnFirst.Name = "btnFirst"
        Me.btnFirst.OnHoverBaseColor = System.Drawing.Color.FromArgb(CType(CType(64, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.btnFirst.OnHoverBorderColor = System.Drawing.Color.Black
        Me.btnFirst.OnHoverForeColor = System.Drawing.Color.White
        Me.btnFirst.OnHoverImage = Nothing
        Me.btnFirst.OnPressedColor = System.Drawing.Color.Black
        Me.btnFirst.Size = New System.Drawing.Size(35, 33)
        Me.btnFirst.TabIndex = 51
        Me.btnFirst.Text = "<"
        '
        'btnLast
        '
        Me.btnLast.AnimationHoverSpeed = 0.07!
        Me.btnLast.AnimationSpeed = 0.03!
        Me.btnLast.BaseColor = System.Drawing.Color.Maroon
        Me.btnLast.BorderColor = System.Drawing.Color.Black
        Me.btnLast.DialogResult = System.Windows.Forms.DialogResult.None
        Me.btnLast.FocusedColor = System.Drawing.Color.Empty
        Me.btnLast.Font = New System.Drawing.Font("Segoe UI", 9.0!)
        Me.btnLast.ForeColor = System.Drawing.Color.White
        Me.btnLast.Image = Nothing
        Me.btnLast.ImageSize = New System.Drawing.Size(52, 52)
        Me.btnLast.Location = New System.Drawing.Point(1072, 212)
        Me.btnLast.Name = "btnLast"
        Me.btnLast.OnHoverBaseColor = System.Drawing.Color.FromArgb(CType(CType(64, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.btnLast.OnHoverBorderColor = System.Drawing.Color.Black
        Me.btnLast.OnHoverForeColor = System.Drawing.Color.White
        Me.btnLast.OnHoverImage = Nothing
        Me.btnLast.OnPressedColor = System.Drawing.Color.Black
        Me.btnLast.Size = New System.Drawing.Size(35, 33)
        Me.btnLast.TabIndex = 50
        Me.btnLast.Text = ">"
        '
        'btnNext
        '
        Me.btnNext.AnimationHoverSpeed = 0.07!
        Me.btnNext.AnimationSpeed = 0.03!
        Me.btnNext.BaseColor = System.Drawing.Color.Maroon
        Me.btnNext.BorderColor = System.Drawing.Color.Black
        Me.btnNext.DialogResult = System.Windows.Forms.DialogResult.None
        Me.btnNext.FocusedColor = System.Drawing.Color.Empty
        Me.btnNext.Font = New System.Drawing.Font("Segoe UI", 9.0!)
        Me.btnNext.ForeColor = System.Drawing.Color.White
        Me.btnNext.Image = Nothing
        Me.btnNext.ImageSize = New System.Drawing.Size(52, 52)
        Me.btnNext.Location = New System.Drawing.Point(1113, 212)
        Me.btnNext.Name = "btnNext"
        Me.btnNext.OnHoverBaseColor = System.Drawing.Color.FromArgb(CType(CType(64, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.btnNext.OnHoverBorderColor = System.Drawing.Color.Black
        Me.btnNext.OnHoverForeColor = System.Drawing.Color.White
        Me.btnNext.OnHoverImage = Nothing
        Me.btnNext.OnPressedColor = System.Drawing.Color.Black
        Me.btnNext.Size = New System.Drawing.Size(35, 33)
        Me.btnNext.TabIndex = 49
        Me.btnNext.Text = ">>"
        '
        'btnDelete
        '
        Me.btnDelete.AnimationHoverSpeed = 0.07!
        Me.btnDelete.AnimationSpeed = 0.03!
        Me.btnDelete.BackColor = System.Drawing.Color.Transparent
        Me.btnDelete.BaseColor = System.Drawing.Color.Maroon
        Me.btnDelete.BorderColor = System.Drawing.Color.Black
        Me.btnDelete.Cursor = System.Windows.Forms.Cursors.Hand
        Me.btnDelete.DialogResult = System.Windows.Forms.DialogResult.None
        Me.btnDelete.FocusedColor = System.Drawing.Color.Empty
        Me.btnDelete.Font = New System.Drawing.Font("Segoe UI", 18.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnDelete.ForeColor = System.Drawing.Color.White
        Me.btnDelete.Image = CType(resources.GetObject("btnDelete.Image"), System.Drawing.Image)
        Me.btnDelete.ImageAlign = System.Windows.Forms.HorizontalAlignment.Center
        Me.btnDelete.ImageSize = New System.Drawing.Size(30, 30)
        Me.btnDelete.Location = New System.Drawing.Point(17, 606)
        Me.btnDelete.Name = "btnDelete"
        Me.btnDelete.OnHoverBaseColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.btnDelete.OnHoverBorderColor = System.Drawing.Color.Black
        Me.btnDelete.OnHoverForeColor = System.Drawing.Color.White
        Me.btnDelete.OnHoverImage = Nothing
        Me.btnDelete.OnPressedColor = System.Drawing.Color.Black
        Me.btnDelete.Size = New System.Drawing.Size(1137, 75)
        Me.btnDelete.TabIndex = 48
        Me.btnDelete.Text = "Delete Product"
        Me.btnDelete.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'dgStock
        '
        Me.dgStock.AllowUserToAddRows = False
        Me.dgStock.AllowUserToDeleteRows = False
        Me.dgStock.AllowUserToResizeColumns = False
        Me.dgStock.AllowUserToResizeRows = False
        DataGridViewCellStyle9.BackColor = System.Drawing.Color.White
        Me.dgStock.AlternatingRowsDefaultCellStyle = DataGridViewCellStyle9
        Me.dgStock.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill
        Me.dgStock.BackgroundColor = System.Drawing.Color.FromArgb(CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer))
        Me.dgStock.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.dgStock.CellBorderStyle = System.Windows.Forms.DataGridViewCellBorderStyle.SingleHorizontal
        Me.dgStock.ColumnHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None
        DataGridViewCellStyle10.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter
        DataGridViewCellStyle10.BackColor = System.Drawing.Color.Maroon
        DataGridViewCellStyle10.Font = New System.Drawing.Font("Segoe UI", 10.5!)
        DataGridViewCellStyle10.ForeColor = System.Drawing.Color.White
        DataGridViewCellStyle10.SelectionBackColor = System.Drawing.SystemColors.Highlight
        DataGridViewCellStyle10.SelectionForeColor = System.Drawing.SystemColors.HighlightText
        DataGridViewCellStyle10.WrapMode = System.Windows.Forms.DataGridViewTriState.[True]
        Me.dgStock.ColumnHeadersDefaultCellStyle = DataGridViewCellStyle10
        Me.dgStock.ColumnHeadersHeight = 21
        DataGridViewCellStyle11.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter
        DataGridViewCellStyle11.BackColor = System.Drawing.Color.White
        DataGridViewCellStyle11.Font = New System.Drawing.Font("Segoe UI", 10.5!)
        DataGridViewCellStyle11.ForeColor = System.Drawing.Color.FromArgb(CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer))
        DataGridViewCellStyle11.SelectionBackColor = System.Drawing.Color.FromArgb(CType(CType(64, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer))
        DataGridViewCellStyle11.SelectionForeColor = System.Drawing.Color.White
        DataGridViewCellStyle11.WrapMode = System.Windows.Forms.DataGridViewTriState.[False]
        Me.dgStock.DefaultCellStyle = DataGridViewCellStyle11
        Me.dgStock.EnableHeadersVisualStyles = False
        Me.dgStock.GridColor = System.Drawing.Color.FromArgb(CType(CType(64, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.dgStock.Location = New System.Drawing.Point(19, 261)
        Me.dgStock.Name = "dgStock"
        Me.dgStock.ReadOnly = True
        Me.dgStock.RowHeadersVisible = False
        DataGridViewCellStyle12.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter
        Me.dgStock.RowsDefaultCellStyle = DataGridViewCellStyle12
        Me.dgStock.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect
        Me.dgStock.Size = New System.Drawing.Size(1135, 327)
        Me.dgStock.TabIndex = 47
        Me.dgStock.Theme = Guna.UI.WinForms.GunaDataGridViewPresetThemes.Guna
        Me.dgStock.ThemeStyle.AlternatingRowsStyle.BackColor = System.Drawing.Color.White
        Me.dgStock.ThemeStyle.AlternatingRowsStyle.Font = Nothing
        Me.dgStock.ThemeStyle.AlternatingRowsStyle.ForeColor = System.Drawing.Color.Empty
        Me.dgStock.ThemeStyle.AlternatingRowsStyle.SelectionBackColor = System.Drawing.Color.Empty
        Me.dgStock.ThemeStyle.AlternatingRowsStyle.SelectionForeColor = System.Drawing.Color.Empty
        Me.dgStock.ThemeStyle.BackColor = System.Drawing.Color.FromArgb(CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer))
        Me.dgStock.ThemeStyle.GridColor = System.Drawing.Color.FromArgb(CType(CType(64, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.dgStock.ThemeStyle.HeaderStyle.BackColor = System.Drawing.Color.Maroon
        Me.dgStock.ThemeStyle.HeaderStyle.BorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None
        Me.dgStock.ThemeStyle.HeaderStyle.Font = New System.Drawing.Font("Segoe UI", 10.5!)
        Me.dgStock.ThemeStyle.HeaderStyle.ForeColor = System.Drawing.Color.White
        Me.dgStock.ThemeStyle.HeaderStyle.HeaightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.EnableResizing
        Me.dgStock.ThemeStyle.HeaderStyle.Height = 21
        Me.dgStock.ThemeStyle.ReadOnly = True
        Me.dgStock.ThemeStyle.RowsStyle.BackColor = System.Drawing.Color.White
        Me.dgStock.ThemeStyle.RowsStyle.BorderStyle = System.Windows.Forms.DataGridViewCellBorderStyle.SingleHorizontal
        Me.dgStock.ThemeStyle.RowsStyle.Font = New System.Drawing.Font("Segoe UI", 10.5!)
        Me.dgStock.ThemeStyle.RowsStyle.ForeColor = System.Drawing.Color.FromArgb(CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer))
        Me.dgStock.ThemeStyle.RowsStyle.Height = 22
        Me.dgStock.ThemeStyle.RowsStyle.SelectionBackColor = System.Drawing.Color.FromArgb(CType(CType(64, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.dgStock.ThemeStyle.RowsStyle.SelectionForeColor = System.Drawing.Color.White
        '
        'pnAddProduct
        '
        Me.pnAddProduct.Controls.Add(Me.Panel5)
        Me.pnAddProduct.Controls.Add(Me.Label8)
        Me.pnAddProduct.Controls.Add(Me.txtSellingPrice)
        Me.pnAddProduct.Controls.Add(Me.btnAdd)
        Me.pnAddProduct.Controls.Add(Me.Label5)
        Me.pnAddProduct.Controls.Add(Me.txtBuyingPrice)
        Me.pnAddProduct.Controls.Add(Me.txtProductQuan)
        Me.pnAddProduct.Controls.Add(Me.txtDescription)
        Me.pnAddProduct.Controls.Add(Me.Label10)
        Me.pnAddProduct.Controls.Add(Me.txtCategory)
        Me.pnAddProduct.Controls.Add(Me.Label7)
        Me.pnAddProduct.Controls.Add(Me.Label6)
        Me.pnAddProduct.Controls.Add(Me.Label4)
        Me.pnAddProduct.Controls.Add(Me.txtProductName)
        Me.pnAddProduct.Controls.Add(Me.Label9)
        Me.pnAddProduct.Controls.Add(Me.txtProductID)
        Me.pnAddProduct.Controls.Add(Me.btnUpload)
        Me.pnAddProduct.Controls.Add(Me.pdID)
        Me.pnAddProduct.Dock = System.Windows.Forms.DockStyle.Fill
        Me.pnAddProduct.Location = New System.Drawing.Point(202, 0)
        Me.pnAddProduct.Name = "pnAddProduct"
        Me.pnAddProduct.Size = New System.Drawing.Size(1166, 728)
        Me.pnAddProduct.TabIndex = 84
        Me.pnAddProduct.Visible = False
        '
        'Panel5
        '
        Me.Panel5.BackColor = System.Drawing.Color.FromArgb(CType(CType(64, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.Panel5.Controls.Add(Me.Label16)
        Me.Panel5.Location = New System.Drawing.Point(143, 189)
        Me.Panel5.Name = "Panel5"
        Me.Panel5.Size = New System.Drawing.Size(920, 37)
        Me.Panel5.TabIndex = 80
        '
        'Label16
        '
        Me.Label16.AutoSize = True
        Me.Label16.Font = New System.Drawing.Font("Segoe UI", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label16.ForeColor = System.Drawing.Color.White
        Me.Label16.Location = New System.Drawing.Point(14, 10)
        Me.Label16.Name = "Label16"
        Me.Label16.Size = New System.Drawing.Size(176, 17)
        Me.Label16.TabIndex = 80
        Me.Label16.Text = "Stock Adding Product Page"
        '
        'Label8
        '
        Me.Label8.AutoSize = True
        Me.Label8.Font = New System.Drawing.Font("Segoe UI", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label8.ForeColor = System.Drawing.Color.FromArgb(CType(CType(64, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.Label8.Location = New System.Drawing.Point(754, 392)
        Me.Label8.Name = "Label8"
        Me.Label8.Size = New System.Drawing.Size(92, 17)
        Me.Label8.TabIndex = 78
        Me.Label8.Text = "Selling Price :"
        '
        'txtSellingPrice
        '
        Me.txtSellingPrice.BackColor = System.Drawing.Color.Transparent
        Me.txtSellingPrice.BaseColor = System.Drawing.Color.White
        Me.txtSellingPrice.BorderColor = System.Drawing.Color.FromArgb(CType(CType(64, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.txtSellingPrice.BorderSize = 1
        Me.txtSellingPrice.Cursor = System.Windows.Forms.Cursors.IBeam
        Me.txtSellingPrice.FocusedBaseColor = System.Drawing.Color.White
        Me.txtSellingPrice.FocusedBorderColor = System.Drawing.Color.Maroon
        Me.txtSellingPrice.FocusedForeColor = System.Drawing.Color.FromArgb(CType(CType(64, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.txtSellingPrice.Font = New System.Drawing.Font("Segoe UI", 9.0!)
        Me.txtSellingPrice.ForeColor = System.Drawing.Color.FromArgb(CType(CType(64, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.txtSellingPrice.Location = New System.Drawing.Point(857, 381)
        Me.txtSellingPrice.Name = "txtSellingPrice"
        Me.txtSellingPrice.PasswordChar = Global.Microsoft.VisualBasic.ChrW(0)
        Me.txtSellingPrice.Radius = 5
        Me.txtSellingPrice.SelectedText = ""
        Me.txtSellingPrice.Size = New System.Drawing.Size(196, 34)
        Me.txtSellingPrice.TabIndex = 77
        '
        'btnAdd
        '
        Me.btnAdd.AnimationHoverSpeed = 0.07!
        Me.btnAdd.AnimationSpeed = 0.03!
        Me.btnAdd.BaseColor = System.Drawing.Color.Maroon
        Me.btnAdd.BorderColor = System.Drawing.Color.Black
        Me.btnAdd.Cursor = System.Windows.Forms.Cursors.Hand
        Me.btnAdd.DialogResult = System.Windows.Forms.DialogResult.None
        Me.btnAdd.FocusedColor = System.Drawing.Color.Empty
        Me.btnAdd.Font = New System.Drawing.Font("Segoe UI", 14.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnAdd.ForeColor = System.Drawing.Color.White
        Me.btnAdd.Image = CType(resources.GetObject("btnAdd.Image"), System.Drawing.Image)
        Me.btnAdd.ImageAlign = System.Windows.Forms.HorizontalAlignment.Center
        Me.btnAdd.ImageSize = New System.Drawing.Size(30, 30)
        Me.btnAdd.Location = New System.Drawing.Point(143, 511)
        Me.btnAdd.Name = "btnAdd"
        Me.btnAdd.OnHoverBaseColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.btnAdd.OnHoverBorderColor = System.Drawing.Color.Black
        Me.btnAdd.OnHoverForeColor = System.Drawing.Color.White
        Me.btnAdd.OnHoverImage = Nothing
        Me.btnAdd.OnPressedColor = System.Drawing.Color.Black
        Me.btnAdd.Size = New System.Drawing.Size(920, 75)
        Me.btnAdd.TabIndex = 76
        Me.btnAdd.Text = "Add Product"
        Me.btnAdd.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.Font = New System.Drawing.Font("Segoe UI", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label5.ForeColor = System.Drawing.Color.FromArgb(CType(CType(64, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.Label5.Location = New System.Drawing.Point(753, 335)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(97, 17)
        Me.Label5.TabIndex = 75
        Me.Label5.Text = "Buying Price : "
        '
        'txtBuyingPrice
        '
        Me.txtBuyingPrice.BackColor = System.Drawing.Color.Transparent
        Me.txtBuyingPrice.BaseColor = System.Drawing.Color.White
        Me.txtBuyingPrice.BorderColor = System.Drawing.Color.FromArgb(CType(CType(64, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.txtBuyingPrice.BorderSize = 1
        Me.txtBuyingPrice.Cursor = System.Windows.Forms.Cursors.IBeam
        Me.txtBuyingPrice.FocusedBaseColor = System.Drawing.Color.White
        Me.txtBuyingPrice.FocusedBorderColor = System.Drawing.Color.Maroon
        Me.txtBuyingPrice.FocusedForeColor = System.Drawing.Color.FromArgb(CType(CType(64, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.txtBuyingPrice.Font = New System.Drawing.Font("Segoe UI", 9.0!)
        Me.txtBuyingPrice.ForeColor = System.Drawing.Color.FromArgb(CType(CType(64, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.txtBuyingPrice.Location = New System.Drawing.Point(856, 324)
        Me.txtBuyingPrice.Name = "txtBuyingPrice"
        Me.txtBuyingPrice.PasswordChar = Global.Microsoft.VisualBasic.ChrW(0)
        Me.txtBuyingPrice.Radius = 5
        Me.txtBuyingPrice.SelectedText = ""
        Me.txtBuyingPrice.Size = New System.Drawing.Size(196, 34)
        Me.txtBuyingPrice.TabIndex = 74
        '
        'txtProductQuan
        '
        Me.txtProductQuan.BackColor = System.Drawing.Color.White
        Me.txtProductQuan.BorderColor = System.Drawing.Color.FromArgb(CType(CType(64, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.txtProductQuan.BorderRadius = 4
        Me.txtProductQuan.Cursor = System.Windows.Forms.Cursors.IBeam
        Me.txtProductQuan.DisabledState.BorderColor = System.Drawing.Color.FromArgb(CType(CType(208, Byte), Integer), CType(CType(208, Byte), Integer), CType(CType(208, Byte), Integer))
        Me.txtProductQuan.DisabledState.FillColor = System.Drawing.Color.FromArgb(CType(CType(226, Byte), Integer), CType(CType(226, Byte), Integer), CType(CType(226, Byte), Integer))
        Me.txtProductQuan.DisabledState.ForeColor = System.Drawing.Color.FromArgb(CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer))
        Me.txtProductQuan.DisabledState.Parent = Me.txtProductQuan
        Me.txtProductQuan.DisabledState.UpDownButtonFillColor = System.Drawing.Color.FromArgb(CType(CType(177, Byte), Integer), CType(CType(177, Byte), Integer), CType(CType(177, Byte), Integer))
        Me.txtProductQuan.DisabledState.UpDownButtonForeColor = System.Drawing.Color.FromArgb(CType(CType(203, Byte), Integer), CType(CType(203, Byte), Integer), CType(CType(203, Byte), Integer))
        Me.txtProductQuan.FocusedState.BorderColor = System.Drawing.Color.Maroon
        Me.txtProductQuan.FocusedState.Parent = Me.txtProductQuan
        Me.txtProductQuan.FocusedState.UpDownButtonFillColor = System.Drawing.Color.Maroon
        Me.txtProductQuan.FocusedState.UpDownButtonForeColor = System.Drawing.Color.White
        Me.txtProductQuan.Font = New System.Drawing.Font("Segoe UI", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtProductQuan.ForeColor = System.Drawing.Color.FromArgb(CType(CType(64, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.txtProductQuan.Location = New System.Drawing.Point(856, 273)
        Me.txtProductQuan.Maximum = New Decimal(New Integer() {1000, 0, 0, 0})
        Me.txtProductQuan.Name = "txtProductQuan"
        Me.txtProductQuan.ShadowDecoration.Color = System.Drawing.Color.White
        Me.txtProductQuan.ShadowDecoration.Parent = Me.txtProductQuan
        Me.txtProductQuan.Size = New System.Drawing.Size(197, 32)
        Me.txtProductQuan.TabIndex = 73
        Me.txtProductQuan.UpDownButtonFillColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer))
        '
        'txtDescription
        '
        Me.txtDescription.BackColor = System.Drawing.Color.Transparent
        Me.txtDescription.BaseColor = System.Drawing.Color.White
        Me.txtDescription.BorderColor = System.Drawing.Color.FromArgb(CType(CType(64, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.txtDescription.BorderSize = 1
        Me.txtDescription.Cursor = System.Windows.Forms.Cursors.IBeam
        Me.txtDescription.FocusedBaseColor = System.Drawing.Color.White
        Me.txtDescription.FocusedBorderColor = System.Drawing.Color.Maroon
        Me.txtDescription.FocusedForeColor = System.Drawing.Color.FromArgb(CType(CType(64, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.txtDescription.Font = New System.Drawing.Font("Segoe UI", 9.0!)
        Me.txtDescription.ForeColor = System.Drawing.Color.FromArgb(CType(CType(64, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.txtDescription.Location = New System.Drawing.Point(525, 435)
        Me.txtDescription.Name = "txtDescription"
        Me.txtDescription.PasswordChar = Global.Microsoft.VisualBasic.ChrW(0)
        Me.txtDescription.Radius = 5
        Me.txtDescription.SelectedText = ""
        Me.txtDescription.Size = New System.Drawing.Size(196, 34)
        Me.txtDescription.TabIndex = 72
        '
        'Label10
        '
        Me.Label10.AutoSize = True
        Me.Label10.Font = New System.Drawing.Font("Segoe UI", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label10.ForeColor = System.Drawing.Color.FromArgb(CType(CType(64, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.Label10.Location = New System.Drawing.Point(411, 445)
        Me.Label10.Name = "Label10"
        Me.Label10.Size = New System.Drawing.Size(91, 17)
        Me.Label10.TabIndex = 71
        Me.Label10.Text = "Description : "
        '
        'txtCategory
        '
        Me.txtCategory.BackColor = System.Drawing.Color.Transparent
        Me.txtCategory.BaseColor = System.Drawing.Color.White
        Me.txtCategory.BorderColor = System.Drawing.Color.FromArgb(CType(CType(64, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.txtCategory.BorderSize = 1
        Me.txtCategory.Cursor = System.Windows.Forms.Cursors.IBeam
        Me.txtCategory.FocusedBaseColor = System.Drawing.Color.White
        Me.txtCategory.FocusedBorderColor = System.Drawing.Color.Maroon
        Me.txtCategory.FocusedForeColor = System.Drawing.Color.FromArgb(CType(CType(64, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.txtCategory.Font = New System.Drawing.Font("Segoe UI", 9.0!)
        Me.txtCategory.ForeColor = System.Drawing.Color.FromArgb(CType(CType(64, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.txtCategory.Location = New System.Drawing.Point(525, 381)
        Me.txtCategory.Name = "txtCategory"
        Me.txtCategory.PasswordChar = Global.Microsoft.VisualBasic.ChrW(0)
        Me.txtCategory.Radius = 5
        Me.txtCategory.SelectedText = ""
        Me.txtCategory.Size = New System.Drawing.Size(196, 34)
        Me.txtCategory.TabIndex = 70
        '
        'Label7
        '
        Me.Label7.AutoSize = True
        Me.Label7.Font = New System.Drawing.Font("Segoe UI", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label7.ForeColor = System.Drawing.Color.FromArgb(CType(CType(64, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.Label7.Location = New System.Drawing.Point(411, 390)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(76, 17)
        Me.Label7.TabIndex = 65
        Me.Label7.Text = "Category : "
        '
        'Label6
        '
        Me.Label6.AutoSize = True
        Me.Label6.Font = New System.Drawing.Font("Segoe UI", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label6.ForeColor = System.Drawing.Color.FromArgb(CType(CType(64, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.Label6.Location = New System.Drawing.Point(753, 285)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(74, 17)
        Me.Label6.TabIndex = 63
        Me.Label6.Text = "Quantity : "
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Font = New System.Drawing.Font("Segoe UI", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label4.ForeColor = System.Drawing.Color.FromArgb(CType(CType(64, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.Label4.Location = New System.Drawing.Point(411, 340)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(108, 17)
        Me.Label4.TabIndex = 59
        Me.Label4.Text = "Product Name : "
        '
        'txtProductName
        '
        Me.txtProductName.BackColor = System.Drawing.Color.Transparent
        Me.txtProductName.BaseColor = System.Drawing.Color.White
        Me.txtProductName.BorderColor = System.Drawing.Color.FromArgb(CType(CType(64, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.txtProductName.BorderSize = 1
        Me.txtProductName.Cursor = System.Windows.Forms.Cursors.IBeam
        Me.txtProductName.FocusedBaseColor = System.Drawing.Color.White
        Me.txtProductName.FocusedBorderColor = System.Drawing.Color.Maroon
        Me.txtProductName.FocusedForeColor = System.Drawing.Color.FromArgb(CType(CType(64, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.txtProductName.Font = New System.Drawing.Font("Segoe UI", 9.0!)
        Me.txtProductName.ForeColor = System.Drawing.Color.FromArgb(CType(CType(64, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.txtProductName.Location = New System.Drawing.Point(525, 330)
        Me.txtProductName.Name = "txtProductName"
        Me.txtProductName.PasswordChar = Global.Microsoft.VisualBasic.ChrW(0)
        Me.txtProductName.Radius = 5
        Me.txtProductName.SelectedText = ""
        Me.txtProductName.Size = New System.Drawing.Size(196, 34)
        Me.txtProductName.TabIndex = 58
        '
        'Label9
        '
        Me.Label9.AutoSize = True
        Me.Label9.Font = New System.Drawing.Font("Segoe UI", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label9.ForeColor = System.Drawing.Color.FromArgb(CType(CType(64, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.Label9.Location = New System.Drawing.Point(411, 291)
        Me.Label9.Name = "Label9"
        Me.Label9.Size = New System.Drawing.Size(86, 17)
        Me.Label9.TabIndex = 57
        Me.Label9.Text = "Product ID : "
        '
        'txtProductID
        '
        Me.txtProductID.BackColor = System.Drawing.Color.Transparent
        Me.txtProductID.BaseColor = System.Drawing.Color.White
        Me.txtProductID.BorderColor = System.Drawing.Color.FromArgb(CType(CType(64, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.txtProductID.BorderSize = 1
        Me.txtProductID.Cursor = System.Windows.Forms.Cursors.IBeam
        Me.txtProductID.FocusedBaseColor = System.Drawing.Color.White
        Me.txtProductID.FocusedBorderColor = System.Drawing.Color.Maroon
        Me.txtProductID.FocusedForeColor = System.Drawing.Color.FromArgb(CType(CType(64, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.txtProductID.Font = New System.Drawing.Font("Segoe UI", 9.0!)
        Me.txtProductID.ForeColor = System.Drawing.Color.FromArgb(CType(CType(64, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.txtProductID.Location = New System.Drawing.Point(525, 277)
        Me.txtProductID.Name = "txtProductID"
        Me.txtProductID.PasswordChar = Global.Microsoft.VisualBasic.ChrW(0)
        Me.txtProductID.Radius = 5
        Me.txtProductID.SelectedText = ""
        Me.txtProductID.Size = New System.Drawing.Size(196, 34)
        Me.txtProductID.TabIndex = 56
        '
        'btnUpload
        '
        Me.btnUpload.AnimationHoverSpeed = 0.07!
        Me.btnUpload.AnimationSpeed = 0.03!
        Me.btnUpload.BackColor = System.Drawing.Color.White
        Me.btnUpload.BaseColor = System.Drawing.Color.FromArgb(CType(CType(64, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.btnUpload.BorderColor = System.Drawing.Color.Black
        Me.btnUpload.Cursor = System.Windows.Forms.Cursors.Hand
        Me.btnUpload.DialogResult = System.Windows.Forms.DialogResult.None
        Me.btnUpload.FocusedColor = System.Drawing.Color.Empty
        Me.btnUpload.Font = New System.Drawing.Font("Segoe UI", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnUpload.ForeColor = System.Drawing.Color.White
        Me.btnUpload.Image = CType(resources.GetObject("btnUpload.Image"), System.Drawing.Image)
        Me.btnUpload.ImageAlign = System.Windows.Forms.HorizontalAlignment.Center
        Me.btnUpload.ImageSize = New System.Drawing.Size(15, 15)
        Me.btnUpload.Location = New System.Drawing.Point(144, 459)
        Me.btnUpload.Name = "btnUpload"
        Me.btnUpload.OnHoverBaseColor = System.Drawing.Color.FromArgb(CType(CType(64, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.btnUpload.OnHoverBorderColor = System.Drawing.Color.Black
        Me.btnUpload.OnHoverForeColor = System.Drawing.Color.White
        Me.btnUpload.OnHoverImage = Nothing
        Me.btnUpload.OnPressedColor = System.Drawing.Color.Black
        Me.btnUpload.Size = New System.Drawing.Size(244, 29)
        Me.btnUpload.TabIndex = 7
        Me.btnUpload.Text = "Upload Image"
        Me.btnUpload.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'pdID
        '
        Me.pdID.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.pdID.Location = New System.Drawing.Point(144, 264)
        Me.pdID.Name = "pdID"
        Me.pdID.Size = New System.Drawing.Size(244, 189)
        Me.pdID.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.pdID.TabIndex = 6
        Me.pdID.TabStop = False
        '
        'd1
        '
        Me.d1.Location = New System.Drawing.Point(0, 0)
        Me.d1.Name = "d1"
        Me.d1.Size = New System.Drawing.Size(200, 20)
        Me.d1.TabIndex = 81
        '
        'InventoryDashBoard
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.Color.White
        Me.ClientSize = New System.Drawing.Size(1368, 728)
        Me.Controls.Add(Me.pnStock)
        Me.Controls.Add(Me.pnEditPage)
        Me.Controls.Add(Me.pnAddProduct)
        Me.Controls.Add(Me.btnAP)
        Me.Controls.Add(Me.btnSP)
        Me.Controls.Add(Me.btnEP)
        Me.Controls.Add(Me.Panel2)
        Me.Controls.Add(Me.Panel1)
        Me.Controls.Add(Me.d1)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None
        Me.Name = "InventoryDashBoard"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "StockDashboard"
        Me.Panel1.ResumeLayout(False)
        Me.Panel1.PerformLayout()
        Me.Panel2.ResumeLayout(False)
        Me.Panel2.PerformLayout()
        Me.pnEditPage.ResumeLayout(False)
        Me.pnEditPage.PerformLayout()
        Me.Panel3.ResumeLayout(False)
        Me.Panel3.PerformLayout()
        CType(Me.Quantity, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.Images, System.ComponentModel.ISupportInitialize).EndInit()
        Me.pnStock.ResumeLayout(False)
        CType(Me.Images1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.Panel4.ResumeLayout(False)
        Me.Panel4.PerformLayout()
        CType(Me.dgStock, System.ComponentModel.ISupportInitialize).EndInit()
        Me.pnAddProduct.ResumeLayout(False)
        Me.pnAddProduct.PerformLayout()
        Me.Panel5.ResumeLayout(False)
        Me.Panel5.PerformLayout()
        CType(Me.txtProductQuan, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.pdID, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)

    End Sub
    Friend WithEvents GunaElipse1 As Guna.UI.WinForms.GunaElipse
    Friend WithEvents Panel1 As System.Windows.Forms.Panel
    Friend WithEvents btnStock As Guna.UI.WinForms.GunaButton
    Friend WithEvents btnEditing As Guna.UI.WinForms.GunaButton
    Friend WithEvents btnAddProduct As Guna.UI.WinForms.GunaButton
    Friend WithEvents btnBack As Guna.UI.WinForms.GunaButton
    Friend WithEvents btnHome As Guna.UI.WinForms.GunaButton
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents OpenFileDialog1 As System.Windows.Forms.OpenFileDialog
    Friend WithEvents Label19 As System.Windows.Forms.Label
    Friend WithEvents btnSP As Guna.UI.WinForms.GunaAdvenceTileButton
    Friend WithEvents btnEP As Guna.UI.WinForms.GunaAdvenceTileButton
    Friend WithEvents btnAP As Guna.UI.WinForms.GunaAdvenceTileButton
    Friend WithEvents Panel2 As System.Windows.Forms.Panel
    Friend WithEvents Label14 As System.Windows.Forms.Label
    Friend WithEvents pnEditPage As System.Windows.Forms.Panel
    Friend WithEvents Panel3 As System.Windows.Forms.Panel
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents Label11 As System.Windows.Forms.Label
    Friend WithEvents SellingPrice As Guna.UI.WinForms.GunaTextBox
    Friend WithEvents btnUpdate As Guna.UI.WinForms.GunaButton
    Friend WithEvents Label12 As System.Windows.Forms.Label
    Friend WithEvents BuyingPrice As Guna.UI.WinForms.GunaTextBox
    Friend WithEvents Quantity As Guna.UI2.WinForms.Guna2NumericUpDown
    Friend WithEvents Description As Guna.UI.WinForms.GunaTextBox
    Friend WithEvents Label13 As System.Windows.Forms.Label
    Friend WithEvents Label15 As System.Windows.Forms.Label
    Friend WithEvents Label17 As System.Windows.Forms.Label
    Friend WithEvents ProductID As Guna.UI.WinForms.GunaTextBox
    Friend WithEvents Images As System.Windows.Forms.PictureBox
    Friend WithEvents pnStock As System.Windows.Forms.Panel
    Friend WithEvents Panel4 As System.Windows.Forms.Panel
    Friend WithEvents Label18 As System.Windows.Forms.Label
    Friend WithEvents btnC As Guna.UI.WinForms.GunaButton
    Friend WithEvents btnSearch As Guna.UI.WinForms.GunaButton
    Friend WithEvents txtSearch As Guna.UI.WinForms.GunaTextBox
    Friend WithEvents btnPrev As Guna.UI.WinForms.GunaCircleButton
    Friend WithEvents btnFirst As Guna.UI.WinForms.GunaCircleButton
    Friend WithEvents btnLast As Guna.UI.WinForms.GunaCircleButton
    Friend WithEvents btnNext As Guna.UI.WinForms.GunaCircleButton
    Friend WithEvents btnDelete As Guna.UI.WinForms.GunaButton
    Friend WithEvents dgStock As Guna.UI.WinForms.GunaDataGridView
    Friend WithEvents pnAddProduct As System.Windows.Forms.Panel
    Friend WithEvents Panel5 As System.Windows.Forms.Panel
    Friend WithEvents Label16 As System.Windows.Forms.Label
    Friend WithEvents Label8 As System.Windows.Forms.Label
    Friend WithEvents txtSellingPrice As Guna.UI.WinForms.GunaTextBox
    Friend WithEvents btnAdd As Guna.UI.WinForms.GunaButton
    Friend WithEvents Label5 As System.Windows.Forms.Label
    Friend WithEvents txtBuyingPrice As Guna.UI.WinForms.GunaTextBox
    Friend WithEvents txtProductQuan As Guna.UI2.WinForms.Guna2NumericUpDown
    Friend WithEvents txtDescription As Guna.UI.WinForms.GunaTextBox
    Friend WithEvents Label10 As System.Windows.Forms.Label
    Friend WithEvents txtCategory As Guna.UI.WinForms.GunaTextBox
    Friend WithEvents Label7 As System.Windows.Forms.Label
    Friend WithEvents Label6 As System.Windows.Forms.Label
    Friend WithEvents Label4 As System.Windows.Forms.Label
    Friend WithEvents txtProductName As Guna.UI.WinForms.GunaTextBox
    Friend WithEvents Label9 As System.Windows.Forms.Label
    Friend WithEvents txtProductID As Guna.UI.WinForms.GunaTextBox
    Friend WithEvents btnUpload As Guna.UI.WinForms.GunaButton
    Friend WithEvents pdID As System.Windows.Forms.PictureBox
    Friend WithEvents Images1 As System.Windows.Forms.PictureBox
    Friend WithEvents btnEdit As Guna.UI.WinForms.GunaButton
    Friend WithEvents btnPrint As Guna.UI.WinForms.GunaButton
    Friend WithEvents SaveFileDialog1 As System.Windows.Forms.SaveFileDialog
    Friend WithEvents d1 As System.Windows.Forms.DateTimePicker
End Class
