﻿Public Class MainForm
    Public XName As String
    Private Sub MainForm_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        lblLoginAs.Text = LoginForm.xpriv
        If LoginForm.xpriv = "User" Then
            ReportViewToolStripMenuItem.Enabled = False
            InventoryToolStripMenuItem.Enabled = False
        End If
        If LoginForm.xpriv = "Admin" Then
            ReportViewToolStripMenuItem.Enabled = True
            InventoryToolStripMenuItem.Enabled = True
        End If
        If LoginForm.xpost = "Cashier" And LoginForm.xname = "cashier" Then
            Cashier.Show()
            LoginForm.Hide()
            Me.Close()
        End If
        dtTime.Value = DateTime.Now
    End Sub
    Private Sub LogoutUserToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles LogoutUserToolStripMenuItem.Click
        Dim counter As Integer
        For counter = 90 To 10 Step -20
            Me.Opacity = counter / 100
            Me.Refresh()
            Threading.Thread.Sleep(5)
        Next counter
        MsgBox("Logout Success", vbInformation, "Logout.")
        LoginForm.txtUsername.Clear()
        LoginForm.txtPassword.Clear()
        Me.Close()
        LoginForm.Show()
    End Sub
    Private Sub SalesReportToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles SalesReportToolStripMenuItem.Click
        SalesReportView.Show()
        Me.Hide()
    End Sub
    Private Sub CashierToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles CashierToolStripMenuItem.Click
        Cashier.Show()
        Me.Hide()
    End Sub
    Private Sub NewUserToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles NewUserToolStripMenuItem.Click
        UserForm.Show()
        Me.Hide()
    End Sub
    Private Sub InventoryToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles InventoryToolStripMenuItem.Click
        InventoryDashBoard.Show()
        Me.Hide()
    End Sub
    Private Sub UserReportToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles UserReportToolStripMenuItem.Click
        UserReportView.Show()
        Me.Hide()
    End Sub
    Private Sub StockReportToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles StockReportToolStripMenuItem.Click
        StockReportView1.Show()
        Me.Hide()
    End Sub
End Class