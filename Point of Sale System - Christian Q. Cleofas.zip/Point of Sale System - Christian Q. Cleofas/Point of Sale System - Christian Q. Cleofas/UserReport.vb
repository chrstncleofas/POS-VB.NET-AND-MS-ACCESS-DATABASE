﻿Public Class UserReport
    Private Sub UserReport_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        'Dim dataset As New DataSet3
        'Dim adapter As New DataSet3TableAdapters.tbluserTableAdapter
        'adapter.Fill(dataset.tbluser)
        'Dim report As New CrystalReport3
        'report.SetDataSource(dataset)
        'CrystalReportViewer1.ReportSource = report
    End Sub

    Private Sub PictureBox1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles PictureBox1.Click
        If MsgBox("Are you sure do you want to close this window?", vbQuestion + vbYesNo, "Closing........") = vbYes Then
            Dim counter As Integer
            For counter = 90 To 10 Step -20
                Me.Opacity = counter / 100
                Me.Refresh()
                Threading.Thread.Sleep(5)
            Next counter
            UserReportView.Show()
            Me.Close()
        End If
    End Sub
End Class