﻿Public Class Cashier02

    Private Sub Cashier02_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        lblVAT.Text = 0.3
    End Sub

End Class