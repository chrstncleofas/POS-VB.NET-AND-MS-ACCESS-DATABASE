﻿Public Class SalesReport
    Private Sub SalesReport_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        'Dim dataset As New DataSet2
        'Dim adapter As New DataSet2TableAdapters.tbltranTableAdapter
        'adapter.Fill(dataset.tbltran)
        'Dim report As New CrystalReport2
        'report.SetDataSource(dataset)
        'CrystalReportViewer1.ReportSource = report
    End Sub
    Private Sub PictureBox1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles PictureBox1.Click
        If MsgBox("Do you want to close this window?", vbQuestion + vbYesNo, "Close.....") = vbYes Then
            Dim counter As Integer
            For counter = 90 To 10 Step -20
                Me.Opacity = counter / 100
                Me.Refresh()
                Threading.Thread.Sleep(5)
            Next counter
            Me.Close()
            SalesReportView.Show()
        Else
            Me.Focus()
        End If
    End Sub
End Class